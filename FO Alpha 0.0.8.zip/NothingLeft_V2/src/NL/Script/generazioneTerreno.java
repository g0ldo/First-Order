package NL.Script;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class generazioneTerreno {
    private int max = 100, tileSize = 40;
    private int terreno[][] = new int[max][max];
    private int i, j, xi = 0, yi = 0;
    private javax.swing.JPanel jPanel1;
    
    public void generaTerreno(JPanel JP1) {
        for(i=0; i < max; i++) {
            for(j=0; j< max; j++) {
                terreno[i][j] = 0;
            }
        }
        
        for(i=0; i < max; i++) {
            for(j=0; j< max; j++) {
                
                if(terreno[i][j] == 0){
                    JLabel jLabel = new javax.swing.JLabel();
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terreno_NothingLeft.png"))); // NOI18N
                    //jLabel.setBackground(Color.red);
                    jLabel.setBorder(new javax.swing.border.MatteBorder(null));
                    jLabel.setOpaque(true);
                    JP1.add(jLabel);
                    jLabel.setBounds(xi, yi, tileSize, tileSize);
                    jLabel.setVisible(true);
                    
                    xi = xi + tileSize;
                }
                
            }
            xi = 0;
            yi = yi + tileSize;
        }
    }
}
