package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class puoiMuovere {
    private ArrayList<JPanel> muri = new ArrayList<>();
    
    public boolean canMove(JLabel JL1, int deltaX, int deltaY) {
        
        // Calcola la nuova posizione proposta
        int newX = JL1.getX() + deltaX;
        int newY = JL1.getY() + deltaY;
        
        // Per ogni jPanel all'interno dell'array muri controlla se la nuova posizione si sovrappone ad esso
        for (JPanel muro : muri) {
            if (muro.getBounds().intersects(newX, newY, JL1.getWidth(), JL1.getHeight())) {
                return false;
            }
        }
        return true;
    }
}
