package Textures.Tiles;

import java.awt.Graphics2D;
import java.io.IOException;
import javax.imageio.ImageIO;
//import java.awt.mage.BufferedImage;


public class TileManager {
    
    Tile[] tile;
    
    
    public void getTileImage() throws IOException{
        
        tile[0] = new Tile();
        tile[0].Image = ImageIO.read(getClass().getResource("/Textures/Tiles/Terreno_NothingLeft.png"));
        
        tile[1] = new Tile();
        tile[1].Image = ImageIO.read(getClass().getResource("/Textures/Tiles/Lago_NothingLeft.png"));
        
        tile[2] = new Tile();
        tile[2].Image = ImageIO.read(getClass().getResource("/Textures/Tiles/Montagna_NothingLeft.png"));
        
    }
    
    public void Draw(Graphics2D g2){
        
        
    }
    
}
