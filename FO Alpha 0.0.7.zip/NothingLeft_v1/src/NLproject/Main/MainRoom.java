package NLproject.Main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MainRoom extends javax.swing.JFrame{
    private static final String nomeGioco = "Nothing Left";
    private int step = 7; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    private boolean isWPressed = false;
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    
    
    private ArrayList<JPanel> muri = new ArrayList<>();
    
    public MainRoom() {
        initComponents();
        
        // Aggiunta dei muri (jPanel) all'interno dell'array
        /*
        muri.add(jPanel2);
        muri.add(jPanel5);
        muri.add(jPanel4);
        muri.add(jPanel6);
        muri.add(jPanel7);
        muri.add(jPanel8);
*/
        
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle(nomeGioco);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setSize(800, 800);
        
        int max = 100, tileSize = 40;
        int terreno[][] = new int[max][max];
        int i, j, xi = 0, yi = 0;

        for(i=0; i < max; i++) {
            for(j=0; j< max; j++) {
                terreno[i][j] = 0;
            }
        }
        
        for(i=0; i < max; i++) {
            for(j=0; j< max; j++) {
                
                if(terreno[i][j] == 0){
                    JLabel jLabel = new javax.swing.JLabel();
                    
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terreno_NothingLeft.png"))); // NOI18N
                    //jLabel.setBackground(Color.red);
                    jLabel.setBorder(new javax.swing.border.MatteBorder(null));
                    jLabel.setOpaque(true);
                    jPanel1.add(jLabel);
                    jLabel.setBounds(xi, yi, tileSize, tileSize);
                    jLabel.setVisible(true);
                    
                    xi = xi + tileSize;
                }
                
            }
            xi = 0;
            yi = yi + tileSize;
        }
        
        /*
        int wcol = 0;
        int wrig = 0;
        
        
        while(wcol < max && wrig < max){
            
            int wx = wcol * tileSize;
            int wy = wrig * tileSize;
            int screenx = wx - Player.getX();
            int screeny = wy - Player.getY();
            
            if(wx + tileSize > Player.getX() - )
        }
*/
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed && canMove(0, -step)) {
                    muoviLabel(0, -step);
                }
                if (isSPressed && canMove(0, step)) {

                    muoviLabel(0, step);
                }
                if (isAPressed && canMove(-step, 0)) {
   
                    muoviLabel(-step, 0);
                }
                if (isDPressed && canMove(step, 0)) {

                    muoviLabel(step, 0);
                }
            }
        });
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Player = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setSize(new java.awt.Dimension(1000, 800));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/w.png"))); // NOI18N
        Player.setBorder(new javax.swing.border.MatteBorder(null));
        Player.setOpaque(true);
        jPanel1.add(Player);
        Player.setBounds(480, 380, 40, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private class KeyHandler implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = true;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = true;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = true;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = true;
                    break;
            }

            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = false;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = false;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = false;
                    break;
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed) {
                // Se nessun tasto WASD è premuto, ferma il timer
                timer.stop();
            }
        }
    }
    
    // Funzione per la gestione del movimento XY
    private void muoviLabel(int deltaX, int deltaY) {
        
        jPanel1.setLocation(jPanel1.getX() - deltaX, jPanel1.getY() -    deltaY);
        Player.setLocation(Player.getX() + deltaX, Player.getY() + deltaY);
        //per ogni if mettere due png che si alternano ogni mezzo secondo per far sembrare il movimento del personaggio 
        
        if(isWPressed){
            
            //se il tasto è premuto l'immagine cambia
            Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/w.png")));
        }
        else if(isAPressed){
            
            //se il tasto è premuto l'immagine cambia
            Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/a.png")));
        }
        else if(isSPressed){
            
            //se il tasto è premuto l'immagine cambia
            Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/s.png")));
        }
        else if(isDPressed){
            
            //se il tasto è premuto l'immagine cambia
            Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/d.png")));
        }
        
    }
    
    private boolean canMove(int deltaX, int deltaY) {
        
        // Calcola la nuova posizione proposta
        int newX = Player.getX() + deltaX;
        int newY = Player.getY() + deltaY;
        
        // Per ogni jPanel all'interno dell'array muri controlla se la nuova posizione si sovrappone ad esso
        for (JPanel muro : muri) {
            if (muro.getBounds().intersects(newX, newY, Player.getWidth(), Player.getHeight())) {
                return false;
            }
        }
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Player;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}