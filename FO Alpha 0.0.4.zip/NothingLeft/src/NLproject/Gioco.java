package NLproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class Gioco extends javax.swing.JFrame{
    private static final String nomeGioco = "Peccatore";
    private int step = 5; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    private boolean isWPressed = false;
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    
    public Gioco() {
        initComponents();

        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle(nomeGioco);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed && canMove(0, -step)) {
                    muoviLabel(0, -step);
                }
                if (isSPressed && canMove(0, step)) {
                    muoviLabel(0, step);
                }
                if (isAPressed && canMove(-step, 0)) {
                    muoviLabel(-step, 0);
                }
                if (isDPressed && canMove(step, 0)) {
                    muoviLabel(step, 0);
                }
            }
        });
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 157, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 297, Short.MAX_VALUE)
        );

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setBorder(new javax.swing.border.MatteBorder(null));
        jLabel1.setOpaque(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(460, 460, 460)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(525, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(429, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private class KeyHandler implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = true;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = true;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = true;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = true;
                    break;
            }

            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = false;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = false;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = false;
                    break;
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed) {
                // Se nessun tasto WASD è premuto, ferma il timer
                timer.stop();
            }
        }
    }
    
    // Funzione per la gestione del movimento XY
    private void muoviLabel(int deltaX, int deltaY) {
        jLabel1.setLocation(jLabel1.getX() + deltaX, jLabel1.getY() + deltaY);
    }
    
    private boolean canMove(int deltaX, int deltaY) {
        
        // Calcola la nuova posizione proposta
        int newX = jLabel1.getX() + deltaX;
        int newY = jLabel1.getY() + deltaY;

        // Controlla se la nuova posizione si sovrappone al muro (JPanel)
        return !jPanel1.getBounds().intersects(newX, newY, jLabel1.getWidth(), jLabel1.getHeight());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}
