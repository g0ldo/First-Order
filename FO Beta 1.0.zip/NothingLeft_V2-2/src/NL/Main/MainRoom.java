package NL.Main;

import NL.Script.ObjectsInteration;
import NL.Script.generazioneTerreno;
import NL.Script.movimentoPersonaggio;
import NL.Script.puoiMuovere;
import NL.Script.CreativeMode;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;


/*
X = 2107
Y = 2548

*/

public class MainRoom extends javax.swing.JFrame{
    private final String nomeGioco = "Nothing Left";
    private int step = 10; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    private int i;
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    NothingLeft menuIniziale = new NothingLeft();
    generazioneTerreno terreno = new generazioneTerreno();
    movimentoPersonaggio personaggio = new movimentoPersonaggio();
    puoiMuovere movimento = new puoiMuovere();
    ObjectsInteration interazioneOggetti = new ObjectsInteration();
    CreativeMode creativa = new CreativeMode();
    
    private boolean isWPressed = false; 
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    private boolean isEPressed = false; 
    private boolean Developer = false; //creativa goliardica per developerzzzz
    
    private ArrayList<JLabel> muri = new ArrayList<>();
    private ArrayList<JLabel> bottoni = new ArrayList<>();
    
    public MainRoom() {
        initComponents();
        
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle("Caricamento in corso, attendere la generazione del terreno...");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setSize(1000,800);
        
        Settings.setVisible(false);
        Settings.setOpaque(true);
        Settings.setBackground(new Color(0,0,0,130));
        
        barraVita.setBackground(new Color(0,0,0,75));
        
        terreno.generaTerreno(jPanel1, muri, bottoni);
        
        bottoni.add(LevaOFF);
        
        this.setTitle(nomeGioco);
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        timer = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed && movimento.canMove(Player, 0, -step, muri, LevaOFF, isEPressed, jPanel1, Developer)) {

                    personaggio.muoviLabel(jPanel1, barraVita, Settings, Player, 0, -step);
                }
                if (isSPressed && movimento.canMove(Player, 0, step, muri, LevaOFF, isEPressed, jPanel1, Developer)) {

                    personaggio.muoviLabel(jPanel1, barraVita, Settings, Player, 0, step);
                }
                if (isAPressed && movimento.canMove(Player, -step, 0, muri, LevaOFF, isEPressed, jPanel1, Developer)) {
   
                    personaggio.muoviLabel(jPanel1, barraVita, Settings, Player, -step, 0);
                }
                if (isDPressed && movimento.canMove(Player, step, 0, muri, LevaOFF, isEPressed, jPanel1, Developer)) {

                    personaggio.muoviLabel(jPanel1, barraVita, Settings, Player, step, 0);
                }
                if (isEPressed) {

                    interazioneOggetti.leva1(Player, Player.getX(), Player.getY(), LevaOFF, isEPressed, jPanel1);
                }
                
            }
        });   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Settings = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        RiprendiButton = new javax.swing.JButton();
        OpzioniButton = new javax.swing.JButton();
        DeveloperButton = new javax.swing.JButton();
        EsciButton = new javax.swing.JButton();
        barraVita = new javax.swing.JPanel();
        faccia = new javax.swing.JLabel();
        oggetto1 = new javax.swing.JLabel();
        oggetto2 = new javax.swing.JLabel();
        oggetto3 = new javax.swing.JLabel();
        vita1 = new javax.swing.JLabel();
        vita2 = new javax.swing.JLabel();
        vita3 = new javax.swing.JLabel();
        vita4 = new javax.swing.JLabel();
        vita5 = new javax.swing.JLabel();
        Player = new javax.swing.JLabel();
        LevaOFF = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setPreferredSize(new java.awt.Dimension(4000, 4500));
        setSize(new java.awt.Dimension(1000, 800));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jPanel1.setLayout(null);

        Settings.setAlignmentX(0.0F);
        Settings.setAlignmentY(0.0F);
        Settings.setPreferredSize(new java.awt.Dimension(1000, 800));
        Settings.setSize(new java.awt.Dimension(1000, 800));
        Settings.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Gioco in Pausa");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Settings.add(jLabel1);
        jLabel1.setBounds(300, 140, 397, 101);

        RiprendiButton.setBackground(new java.awt.Color(0, 0, 0));
        RiprendiButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RiprendiButton.setForeground(new java.awt.Color(255, 255, 255));
        RiprendiButton.setText("Riprendi");
        RiprendiButton.setFocusPainted(false);
        RiprendiButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RiprendiButtonActionPerformed(evt);
            }
        });
        Settings.add(RiprendiButton);
        RiprendiButton.setBounds(360, 240, 270, 60);

        OpzioniButton.setBackground(new java.awt.Color(0, 0, 0));
        OpzioniButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        OpzioniButton.setForeground(new java.awt.Color(255, 255, 255));
        OpzioniButton.setText("Opzioni");
        OpzioniButton.setFocusPainted(false);
        OpzioniButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpzioniButtonActionPerformed(evt);
            }
        });
        Settings.add(OpzioniButton);
        OpzioniButton.setBounds(360, 310, 270, 60);

        DeveloperButton.setBackground(new java.awt.Color(0, 0, 0));
        DeveloperButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        DeveloperButton.setForeground(new java.awt.Color(255, 255, 255));
        DeveloperButton.setText("DeveloperMode: OFF");
        DeveloperButton.setFocusPainted(false);
        DeveloperButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeveloperButtonActionPerformed(evt);
            }
        });
        Settings.add(DeveloperButton);
        DeveloperButton.setBounds(360, 380, 270, 60);

        EsciButton.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton.setText("Esci");
        EsciButton.setFocusPainted(false);
        EsciButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButtonActionPerformed(evt);
            }
        });
        Settings.add(EsciButton);
        EsciButton.setBounds(360, 450, 270, 60);

        jPanel1.add(Settings);
        Settings.setBounds(0, 0, 1000, 800);

        barraVita.setBackground(new java.awt.Color(153, 153, 255));
        barraVita.setLayout(null);

        faccia.setBackground(new java.awt.Color(255, 255, 255));
        faccia.setOpaque(true);
        barraVita.add(faccia);
        faccia.setBounds(259, 6, 70, 58);

        oggetto1.setBackground(new java.awt.Color(51, 51, 51));
        oggetto1.setOpaque(true);
        barraVita.add(oggetto1);
        oggetto1.setBounds(515, 6, 80, 58);

        oggetto2.setBackground(new java.awt.Color(51, 51, 51));
        oggetto2.setOpaque(true);
        barraVita.add(oggetto2);
        oggetto2.setBounds(425, 6, 80, 58);

        oggetto3.setBackground(new java.awt.Color(51, 51, 51));
        oggetto3.setOpaque(true);
        barraVita.add(oggetto3);
        oggetto3.setBounds(335, 6, 80, 58);

        vita1.setBackground(new java.awt.Color(255, 0, 0));
        vita1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita1);
        vita1.setBounds(5, 6, 45, 58);

        vita2.setBackground(new java.awt.Color(255, 0, 0));
        vita2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita2);
        vita2.setBounds(55, 6, 45, 58);

        vita3.setBackground(new java.awt.Color(255, 0, 0));
        vita3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita3);
        vita3.setBounds(105, 6, 45, 58);

        vita4.setBackground(new java.awt.Color(255, 0, 0));
        vita4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita4);
        vita4.setBounds(205, 6, 47, 58);

        vita5.setBackground(new java.awt.Color(255, 0, 0));
        vita5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita5);
        vita5.setBounds(155, 6, 45, 58);

        jPanel1.add(barraVita);
        barraVita.setBounds(210, 680, 600, 70);

        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png"))); // NOI18N
        Player.setBorder(new javax.swing.border.MatteBorder(null));
        Player.setPreferredSize(new java.awt.Dimension(70, 70));
        jPanel1.add(Player);
        Player.setBounds(470, 370, 60, 70);

        LevaOFF.setBackground(new java.awt.Color(255, 255, 255));
        LevaOFF.setForeground(new java.awt.Color(255, 255, 255));
        LevaOFF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/LeverOFF_12.png"))); // NOI18N
        LevaOFF.setMaximumSize(new java.awt.Dimension(49, 49));
        LevaOFF.setMinimumSize(new java.awt.Dimension(49, 49));
        jPanel1.add(LevaOFF);
        LevaOFF.setBounds(2107, 2548, 49, 49);
        LevaOFF.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 4900, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 4000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void DeveloperButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeveloperButtonActionPerformed
        
        DeveloperButton.setText("DeveloperMode: ON");
        Developer = true;
        
        //creativa.setVisible(true);
    }//GEN-LAST:event_DeveloperButtonActionPerformed

    private void RiprendiButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RiprendiButtonActionPerformed
        
        Settings.setVisible(false);
    }//GEN-LAST:event_RiprendiButtonActionPerformed

    private void OpzioniButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpzioniButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OpzioniButtonActionPerformed

    private void EsciButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButtonActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButtonActionPerformed

    
    
    private class KeyHandler implements KeyListener {
        Timer T1 = new Timer (100, new ActionListener() { // W
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T2 = new Timer (100, new ActionListener() { // S
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T3 = new Timer (100, new ActionListener() { // A
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_1.png")));
                        break;
                        
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_2.png")));
                        break;
                        
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T4 = new Timer (100, new ActionListener() { // D
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_1.png")));
                        break;

                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_2.png")));
                        break;
                    
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();
            int controlloP = 0;

            // Ogni numero di fianco all'evento corrisponde al suo codice di animazione
            switch (keyCode) {
                case KeyEvent.VK_W: // 1
                    isWPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T1.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T1.start();
                    } else {
                        T1.start();
                    }
                    
                    break;

                case KeyEvent.VK_S: // 2
                    isSPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T2.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T2.start();
                    } else {
                        T2.start();
                    }
                    
                    break;

                case KeyEvent.VK_A: // 3
                    isAPressed = true;
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T3.start();
                    }
                    
                    break;
                    
                case KeyEvent.VK_D: // 4
                    isDPressed = true; 
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T4.start();
                    }
                    break;
                
                case KeyEvent.VK_E:
                    
                    isEPressed = true;
                    break;
                 
                    
                case KeyEvent.VK_ESCAPE:
                    /*
                    JFrame FinestraCreativa = new Creative();
                    FinestraCreativa.setVisible(true);
                    */
                    Settings.setVisible(true);
                    
                    
                    break;
            }
            
            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    T1.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_fermo.png")));
                    break;
                    
                case KeyEvent.VK_S:
                    isSPressed = false;
                    T2.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png")));
                    break;
                    
                case KeyEvent.VK_A:
                    isAPressed = false;
                    T3.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_fermo.png")));
                    break;
                    
                case KeyEvent.VK_D:
                    isDPressed = false;
                    T4.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_fermo.png")));
                    break;
                    
                case KeyEvent.VK_E:
                    isEPressed = false;
                    break;
                    
                
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed && !isEPressed) {
                // Se nessun tasto WASDE è premuto, ferma il timer
                timer.stop();
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeveloperButton;
    private javax.swing.JButton EsciButton;
    private javax.swing.JLabel LevaOFF;
    private javax.swing.JButton OpzioniButton;
    private javax.swing.JLabel Player;
    private javax.swing.JButton RiprendiButton;
    private javax.swing.JPanel Settings;
    private javax.swing.JPanel barraVita;
    private javax.swing.JLabel faccia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel oggetto1;
    private javax.swing.JLabel oggetto2;
    private javax.swing.JLabel oggetto3;
    private javax.swing.JLabel vita1;
    private javax.swing.JLabel vita2;
    private javax.swing.JLabel vita3;
    private javax.swing.JLabel vita4;
    private javax.swing.JLabel vita5;
    // End of variables declaration//GEN-END:variables

}