package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class generazioneTerreno {
    // Colonne e righe tiles
    private final int maxCol = 100, maxRig = 76, tileSize = 49;
    private int mappa[][] = new int[maxRig][maxCol];
    private String riga[];
    private int i, j, xi = 0, yi = 0, num;
    private int rig = 0, col = 0;
    private javax.swing.JPanel jPanel1;
    private String line;
    
    leggiFile caricaMappa = new leggiFile("/Textures/Tiles/mappa.txt");

    public void generaTerreno(JPanel JP1, ArrayList muri, ArrayList bottoni) {
        
        while(col < maxCol && rig < maxRig){
            
            line = caricaMappa.leggiRiga();
            
            while(col < maxCol){
                
                String riga[] = line.split(" ");
                num = Integer.parseInt(riga[col]);
                 
                mappa[rig][col] = num;
                col++;
            }
            
            if(col == maxCol){
                col = 0;
                rig++;
            }
        }
        
        caricaMappa.chiudi();
        
        
        for(i=0; i < maxRig; i++) {
            for(j=0; j< maxCol; j++) {
                
                JLabel jLabel = new javax.swing.JLabel();
                
                //con lo switch da' problemi
                if(mappa[i][j] == 0) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Erba_0.png"))); 
                    
                }
                else if(mappa[i][j] == 1) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Albero_1.png")));
                    muri.add(jLabel); 
                    
                }
                else if(mappa[i][j] == 2) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Montagna_2.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 3) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_3.png"))); 
                    
                }
                else if(mappa[i][j] == 4) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_4.png")));
                    
                }
                else if(mappa[i][j] == 5) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_5.png"))); 
                    
                }
                else if(mappa[i][j] == 6) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_6.png")));
                    
                }
                else if(mappa[i][j] == 7) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_3_7.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 8) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_4_8.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 9) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_5_9.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 10) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_6_10.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 11) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Erba_11.png")));
                    muri.add(jLabel);
                    
                }
                
                else if(mappa[i][j] == 12) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/LeverOFF_12.png")));
                    bottoni.add(jLabel);
                }
                
                else if(mappa[i][j] == 14) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Albero_14.png")));
                    muri.add(jLabel);
                }
                
                jLabel.setBorder(new javax.swing.border.MatteBorder(null));
                jLabel.setOpaque(true);
                JP1.add(jLabel);
                jLabel.setBounds(xi, yi, tileSize, tileSize);
                jLabel.setVisible(true);
                
                xi = xi + tileSize;
                
            }
            xi = 0;
            yi = yi + tileSize;
        }
    }
}
