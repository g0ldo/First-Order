package NL.Script;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class leggiFile {
    private Scanner input;
    private String nome;

    public leggiFile(String nome) {
        this.nome = nome;
        
        try {
            
            try {
                this.input = new Scanner(new File(getClass().getResource(nome).toURI()));
            } catch (URISyntaxException ex) {
                Logger.getLogger(leggiFile.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
        catch (FileNotFoundException var3) {
            
            System.out.println(var3);
            System.exit(0);
        }
        
    }
    
    public String leggiRiga() {
        String riga = this.input.nextLine();
        return riga;
    }
    
    public String getNome() {
        return this.nome;
    }
    
    public boolean isNotEoF() {
        return this.input.hasNextLine();
    }
    
    public void chiudi() {
        this.input.close();
    }

}
