package NL.Script;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class movimentoPersonaggio {
    
    // Funzione per la gestione del movimento XY
    public void muoviLabel(JPanel JP1, JPanel vita, JPanel settings, JLabel JL1, int deltaX, int deltaY) {
        
        JP1.setLocation(JP1.getX() - deltaX, JP1.getY() - deltaY);
        JL1.setLocation(JL1.getX() + deltaX, JL1.getY() + deltaY);
        
        vita.setLocation(vita.getX() + deltaX, vita.getY() + deltaY);
        settings.setLocation(JL1.getX() + deltaX, JL1.getY() + deltaY);
    }
}
