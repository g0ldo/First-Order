package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class puoiMuovere {
    
    public boolean canMove(JLabel Player, int deltaX, int deltaY, ArrayList<JLabel> muri, JLabel bottone, boolean pressE, JPanel JP1, boolean DM) {
        
        // Calcola la nuova posizione proposta
        int newX = Player.getX() + deltaX;
        int newY = Player.getY() + deltaY;
            
        if(DM == false){
            
            // Per ogni jPanel all'interno dell'array muri controlla se la nuova posizione si sovrappone ad esso
            for (JLabel muro : muri) {
                if (muro.getBounds().intersects(newX, newY, Player.getWidth(), Player.getHeight())) {
                    return false;
                }
            }
        }
        
        
        
        
        return true;

    }
    
}
