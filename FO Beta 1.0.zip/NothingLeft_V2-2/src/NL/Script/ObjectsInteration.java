package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ObjectsInteration {
    
    public void leva1(JLabel Player, int deltaX, int deltaY, JLabel bottone, boolean pressE, JPanel JP1){
        
        int controlloAccendi = 0;
        
        if (bottone.getBounds().intersects(deltaX, deltaY, Player.getWidth(), Player.getHeight()) && controlloAccendi == 0) {
                    
                if(pressE == true && controlloAccendi == 0){            
                    
                    bottone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/LeverON_13.png")));
                    //Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png")));
                    
                    // L'ultima immagine generata viene mostrata sopra a tutti, di conseguenza ricarichiamo il player dopo l'azione soprastante
                    
                    controlloAccendi = 1;
                }
        }
        
        
    }
    
    
}
