
package NL.Main;

import NL.Main.MainRoom;
import java.awt.Color;
import javax.swing.JFrame;

public class Creative extends javax.swing.JFrame {

    private static final String nomeFinestra = "Menu Modalità Creativa";
    
    public Creative() {
        initComponents();
        
        setLayout(null);
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle(nomeFinestra);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        //this.setSize(1000,800);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        CollisioneMuri = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("Collisione muri");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(100, 40, 96, 20);

        CollisioneMuri.setText("OFF");
        CollisioneMuri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CollisioneMuriActionPerformed(evt);
            }
        });
        getContentPane().add(CollisioneMuri);
        CollisioneMuri.setBounds(220, 40, 54, 23);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CollisioneMuriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CollisioneMuriActionPerformed
        
        
    }//GEN-LAST:event_CollisioneMuriActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton CollisioneMuri;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
