package NL.Main;

import NL.Script.ObjectsInteration;
import NL.Script.generazioneTerreno;
import NL.Script.movimentoPersonaggio;
import NL.Script.puoiMuovere;
//import NL.Script.creativeMode;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;


public class MainRoom extends javax.swing.JFrame{
    private final String nomeGioco = "Nothing Left";
    private int step = 8; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    private int i;
    private int puntiVita = 5;
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    NothingLeft menuIniziale = new NothingLeft();
    generazioneTerreno terreno = new generazioneTerreno();
    movimentoPersonaggio personaggio = new movimentoPersonaggio();
    puoiMuovere movimento = new puoiMuovere();
    ObjectsInteration interazioneOggetti = new ObjectsInteration();
    //creativeMode creativa = new creativeMode();
    
    private boolean isWPressed = false; 
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    private boolean isEPressed = false; 
    private boolean Developer = false; //creativa goliardica per developerzzzz
    private boolean pausa = false;
    
    private ArrayList<JLabel> muri = new ArrayList<>();
    private ArrayList<JLabel> muriTemporanei = new ArrayList<>();
    private ArrayList<JLabel> bottoni = new ArrayList<>();

    
    public MainRoom() {
        initComponents();
        
        setLayout(null);
        LabelDev.setVisible(false);
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle("Caricamento in corso, attendere la generazione del terreno...");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(1000,800);
        this.setLocationRelativeTo(null);
        
        settings.setVisible(false);
        settings.setOpaque(true);
        settings.setBackground(new Color(0,0,0,130));
        
        morte.setVisible(false);
        morte.setOpaque(true);
        morte.setBackground(new Color(0,0,0,130));
        
        barraVita.setBackground(new Color(0,0,0,75));
        
        terreno.generaTerreno(jPanel1, muri, bottoni, muriTemporanei);
        
        bottoni.add(LevaOFF);
        muri.add(Macchina);
        muri.add(Camper);
        
        this.setTitle(nomeGioco);
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        menuIniziale.setVisible(false);
        
        timer = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed && movimento.canMove(Player, 0, -step, muri, LevaOFF, isEPressed, jPanel1, Developer, muriTemporanei)) {

                    personaggio.muoviLabel(pausa, jPanel1, barraVita, settings, Player, 0, -step, LabelDev, morte);
                }
                if (isSPressed && movimento.canMove(Player, 0, step, muri, LevaOFF, isEPressed, jPanel1, Developer, muriTemporanei)) {

                    personaggio.muoviLabel(pausa, jPanel1, barraVita, settings, Player, 0, step, LabelDev, morte);
                }
                if (isAPressed && movimento.canMove(Player, -step, 0, muri, LevaOFF, isEPressed, jPanel1, Developer, muriTemporanei)) {
   
                    personaggio.muoviLabel(pausa, jPanel1, barraVita, settings, Player, -step, 0, LabelDev, morte);
                }
                if (isDPressed && movimento.canMove(Player, step, 0, muri, LevaOFF, isEPressed, jPanel1, Developer, muriTemporanei)) {

                    personaggio.muoviLabel(pausa, jPanel1, barraVita, settings, Player, step, 0, LabelDev, morte);
                }
                if (isEPressed) {

                    interazioneOggetti.leva1(Player, Player.getX(), Player.getY(), LevaOFF, isEPressed, jPanel1, muriTemporanei);
                }
                
            }
        });   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        LabelDev = new javax.swing.JLabel();
        morte = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        RigiocaButton = new javax.swing.JButton();
        EsciButton1 = new javax.swing.JButton();
        settings = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        RiprendiButton = new javax.swing.JButton();
        OpzioniButton = new javax.swing.JButton();
        DeveloperButton = new javax.swing.JButton();
        EsciButton = new javax.swing.JButton();
        barraVita = new javax.swing.JPanel();
        oggetto1 = new javax.swing.JLabel();
        oggetto2 = new javax.swing.JLabel();
        oggetto3 = new javax.swing.JLabel();
        vita2 = new javax.swing.JLabel();
        vita3 = new javax.swing.JLabel();
        vita5 = new javax.swing.JLabel();
        vita4 = new javax.swing.JLabel();
        faccia = new javax.swing.JLabel();
        vita1 = new javax.swing.JLabel();
        vuoto5 = new javax.swing.JLabel();
        vuoto1 = new javax.swing.JLabel();
        vuoto4 = new javax.swing.JLabel();
        vuoto2 = new javax.swing.JLabel();
        vuoto3 = new javax.swing.JLabel();
        Player = new javax.swing.JLabel();
        LevaOFF = new javax.swing.JLabel();
        Macchina = new javax.swing.JLabel();
        Camper = new javax.swing.JLabel();
        Fuoco = new javax.swing.JLabel();
        LegnaFuoco = new javax.swing.JLabel();
        npcKetamen = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setPreferredSize(new java.awt.Dimension(4000, 4500));
        setSize(new java.awt.Dimension(1000, 800));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jPanel1.setLayout(null);

        LabelDev.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        LabelDev.setForeground(new java.awt.Color(255, 255, 255));
        LabelDev.setText("DEVELOPER");
        jPanel1.add(LabelDev);
        LabelDev.setBounds(870, 730, 110, 50);

        morte.setAlignmentX(0.0F);
        morte.setAlignmentY(0.0F);
        morte.setPreferredSize(new java.awt.Dimension(1000, 800));
        morte.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Sei morto");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        morte.add(jLabel2);
        jLabel2.setBounds(300, 140, 397, 101);

        RigiocaButton.setBackground(new java.awt.Color(0, 0, 0));
        RigiocaButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RigiocaButton.setForeground(new java.awt.Color(255, 255, 255));
        RigiocaButton.setText("Rigioca");
        RigiocaButton.setFocusPainted(false);
        RigiocaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RigiocaButtonActionPerformed(evt);
            }
        });
        morte.add(RigiocaButton);
        RigiocaButton.setBounds(360, 240, 270, 60);

        EsciButton1.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton1.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton1.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton1.setText("Esci");
        EsciButton1.setFocusPainted(false);
        EsciButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButton1ActionPerformed(evt);
            }
        });
        morte.add(EsciButton1);
        EsciButton1.setBounds(360, 320, 270, 60);

        jPanel1.add(morte);
        morte.setBounds(0, 0, 1000, 800);

        settings.setAlignmentX(0.0F);
        settings.setAlignmentY(0.0F);
        settings.setPreferredSize(new java.awt.Dimension(1000, 800));
        settings.setSize(new java.awt.Dimension(1000, 800));
        settings.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Gioco in Pausa");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        settings.add(jLabel1);
        jLabel1.setBounds(300, 140, 397, 101);

        RiprendiButton.setBackground(new java.awt.Color(0, 0, 0));
        RiprendiButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RiprendiButton.setForeground(new java.awt.Color(255, 255, 255));
        RiprendiButton.setText("Riprendi");
        RiprendiButton.setFocusPainted(false);
        RiprendiButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RiprendiButtonActionPerformed(evt);
            }
        });
        settings.add(RiprendiButton);
        RiprendiButton.setBounds(360, 240, 270, 60);

        OpzioniButton.setBackground(new java.awt.Color(0, 0, 0));
        OpzioniButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        OpzioniButton.setForeground(new java.awt.Color(255, 255, 255));
        OpzioniButton.setText("Opzioni");
        OpzioniButton.setFocusPainted(false);
        OpzioniButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpzioniButtonActionPerformed(evt);
            }
        });
        settings.add(OpzioniButton);
        OpzioniButton.setBounds(360, 310, 270, 60);

        DeveloperButton.setBackground(new java.awt.Color(0, 0, 0));
        DeveloperButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        DeveloperButton.setForeground(new java.awt.Color(255, 255, 255));
        DeveloperButton.setText("DeveloperMode: OFF");
        DeveloperButton.setFocusPainted(false);
        DeveloperButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeveloperButtonActionPerformed(evt);
            }
        });
        settings.add(DeveloperButton);
        DeveloperButton.setBounds(360, 380, 270, 60);

        EsciButton.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton.setText("Esci");
        EsciButton.setFocusPainted(false);
        EsciButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButtonActionPerformed(evt);
            }
        });
        settings.add(EsciButton);
        EsciButton.setBounds(360, 450, 270, 60);

        jPanel1.add(settings);
        settings.setBounds(0, 0, 1000, 800);

        barraVita.setBackground(new java.awt.Color(153, 153, 255));
        barraVita.setLayout(null);

        oggetto1.setBackground(new java.awt.Color(51, 51, 51));
        oggetto1.setOpaque(true);
        barraVita.add(oggetto1);
        oggetto1.setBounds(600, 10, 80, 80);

        oggetto2.setBackground(new java.awt.Color(51, 51, 51));
        oggetto2.setOpaque(true);
        barraVita.add(oggetto2);
        oggetto2.setBounds(510, 10, 80, 80);

        oggetto3.setBackground(new java.awt.Color(51, 51, 51));
        oggetto3.setOpaque(true);
        barraVita.add(oggetto3);
        oggetto3.setBounds(420, 10, 80, 80);

        vita2.setBackground(new java.awt.Color(255, 0, 0));
        vita2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita2);
        vita2.setBounds(170, 20, 45, 58);

        vita3.setBackground(new java.awt.Color(255, 0, 0));
        vita3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita3);
        vita3.setBounds(220, 20, 45, 58);

        vita5.setBackground(new java.awt.Color(255, 0, 0));
        vita5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita5);
        vita5.setBounds(320, 20, 47, 58);

        vita4.setBackground(new java.awt.Color(255, 0, 0));
        vita4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita4);
        vita4.setBounds(270, 20, 45, 58);

        faccia.setBackground(new java.awt.Color(0, 0, 0));
        faccia.setForeground(new java.awt.Color(0, 0, 0));
        faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia0.gif"))); // NOI18N
        faccia.setOpaque(true);
        barraVita.add(faccia);
        faccia.setBounds(0, 0, 100, 100);

        vita1.setBackground(new java.awt.Color(255, 0, 0));
        vita1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita1);
        vita1.setBounds(120, 20, 45, 58);

        vuoto5.setBackground(new java.awt.Color(255, 0, 0));
        vuoto5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto5);
        vuoto5.setBounds(320, 20, 45, 58);

        vuoto1.setBackground(new java.awt.Color(255, 0, 0));
        vuoto1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto1);
        vuoto1.setBounds(120, 20, 45, 58);

        vuoto4.setBackground(new java.awt.Color(255, 0, 0));
        vuoto4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto4);
        vuoto4.setBounds(270, 20, 45, 58);

        vuoto2.setBackground(new java.awt.Color(255, 0, 0));
        vuoto2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto2);
        vuoto2.setBounds(170, 20, 45, 58);

        vuoto3.setBackground(new java.awt.Color(255, 0, 0));
        vuoto3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto3);
        vuoto3.setBounds(220, 20, 45, 58);

        jPanel1.add(barraVita);
        barraVita.setBounds(150, 650, 700, 100);

        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png"))); // NOI18N
        Player.setBorder(new javax.swing.border.MatteBorder(null));
        Player.setPreferredSize(new java.awt.Dimension(70, 70));
        jPanel1.add(Player);
        Player.setBounds(470, 370, 60, 70);

        LevaOFF.setBackground(new java.awt.Color(255, 255, 255));
        LevaOFF.setForeground(new java.awt.Color(255, 255, 255));
        LevaOFF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverOFF_12.png"))); // NOI18N
        LevaOFF.setMaximumSize(new java.awt.Dimension(49, 49));
        LevaOFF.setMinimumSize(new java.awt.Dimension(49, 49));
        jPanel1.add(LevaOFF);
        LevaOFF.setBounds(2107, 2548, 49, 49);

        Macchina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Macchina.png"))); // NOI18N
        Macchina.setPreferredSize(new java.awt.Dimension(100, 100));
        jPanel1.add(Macchina);
        Macchina.setBounds(810, 370, 150, 70);

        Camper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Camper.png"))); // NOI18N
        jPanel1.add(Camper);
        Camper.setBounds(1480, 940, 250, 140);

        Fuoco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/fuoco_gif.gif"))); // NOI18N
        Fuoco.setSize(new java.awt.Dimension(50, 50));
        jPanel1.add(Fuoco);
        Fuoco.setBounds(1590, 1140, 50, 50);

        LegnaFuoco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LegnaFuoco.png"))); // NOI18N
        jPanel1.add(LegnaFuoco);
        LegnaFuoco.setBounds(1600, 1180, 40, 20);

        npcKetamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Ketamen.gif"))); // NOI18N
        jPanel1.add(npcKetamen);
        npcKetamen.setBounds(1500, 1090, 60, 90);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 4900, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 4000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeveloperButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeveloperButtonActionPerformed
        
        if(Developer == false){
            LabelDev.setVisible(true);
            DeveloperButton.setText("DeveloperMode: ON");
            Developer = true;
            //creativa.setVisible(true);
        }
        else{
            LabelDev.setVisible(false);
            DeveloperButton.setText("DeveloperMode: OFF");
            Developer = false;
        }
    }//GEN-LAST:event_DeveloperButtonActionPerformed

    private void RiprendiButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RiprendiButtonActionPerformed
        pausa = false;
        settings.setVisible(false);
        puntiVita = interazioneOggetti.vitaMeno(puntiVita, pausa, vita1, vita2, vita3, vita4, vita5, vuoto1, vuoto2, vuoto3, vuoto4, vuoto5, faccia, morte);
    }//GEN-LAST:event_RiprendiButtonActionPerformed

    private void OpzioniButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpzioniButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OpzioniButtonActionPerformed

    private void EsciButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButtonActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButtonActionPerformed

    private void EsciButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButton1ActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButton1ActionPerformed

    private void RigiocaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RigiocaButtonActionPerformed
        
        MainRoom game = new MainRoom();
        game.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RigiocaButtonActionPerformed
    
    private class KeyHandler implements KeyListener {
        Timer T1 = new Timer (100, new ActionListener() { // W
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T2 = new Timer (100, new ActionListener() { // S
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T3 = new Timer (100, new ActionListener() { // A
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_1.png")));
                        break;
                        
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_2.png")));
                        break;
                        
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T4 = new Timer (100, new ActionListener() { // D
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_1.png")));
                        break;

                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_2.png")));
                        break;
                    
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        
        
        
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            // Ogni numero di fianco all'evento corrisponde al suo codice di animazione
            switch (keyCode) {
                case KeyEvent.VK_W: // 1
                    isWPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T1.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T1.start();
                    } else {
                        T1.start();
                    }
                    
                    break;

                case KeyEvent.VK_S: // 2
                    isSPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T2.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T2.start();
                    } else {
                        T2.start();
                    }
                    
                    break;

                case KeyEvent.VK_A: // 3
                    isAPressed = true;
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T3.start();
                    }
                    
                    break;
                    
                case KeyEvent.VK_D: // 4
                    isDPressed = true; 
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T4.start();
                    }
                    break;
                
                case KeyEvent.VK_E:
                    
                    isEPressed = true;
                    break;
                 
                    
                case KeyEvent.VK_ESCAPE:

                    if(pausa == false){
                        settings.setVisible(true);
                        pausa = true;
                    }
                    else{
                        settings.setVisible(false);
                        pausa = false;
                    }
                    
                    
                    break;
            }
            
            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    T1.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_fermo.png")));
                    break;
                    
                case KeyEvent.VK_S:
                    isSPressed = false;
                    T2.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png")));
                    break;
                    
                case KeyEvent.VK_A:
                    isAPressed = false;
                    T3.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_fermo.png")));
                    break;
                    
                case KeyEvent.VK_D:
                    isDPressed = false;
                    T4.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_fermo.png")));
                    break;
                    
                case KeyEvent.VK_E:
                    isEPressed = false;
                    break;
            
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed && !isEPressed) {
                // Se nessun tasto WASDE è premuto, ferma il timer
                timer.stop();
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Camper;
    private javax.swing.JButton DeveloperButton;
    private javax.swing.JButton EsciButton;
    private javax.swing.JButton EsciButton1;
    private javax.swing.JLabel Fuoco;
    private javax.swing.JLabel LabelDev;
    private javax.swing.JLabel LegnaFuoco;
    private javax.swing.JLabel LevaOFF;
    private javax.swing.JLabel Macchina;
    private javax.swing.JButton OpzioniButton;
    private javax.swing.JLabel Player;
    private javax.swing.JButton RigiocaButton;
    private javax.swing.JButton RiprendiButton;
    private javax.swing.JPanel barraVita;
    private javax.swing.JLabel faccia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel morte;
    private javax.swing.JLabel npcKetamen;
    private javax.swing.JLabel oggetto1;
    private javax.swing.JLabel oggetto2;
    private javax.swing.JLabel oggetto3;
    private javax.swing.JPanel settings;
    private javax.swing.JLabel vita1;
    private javax.swing.JLabel vita2;
    private javax.swing.JLabel vita3;
    private javax.swing.JLabel vita4;
    private javax.swing.JLabel vita5;
    private javax.swing.JLabel vuoto1;
    private javax.swing.JLabel vuoto2;
    private javax.swing.JLabel vuoto3;
    private javax.swing.JLabel vuoto4;
    private javax.swing.JLabel vuoto5;
    // End of variables declaration//GEN-END:variables
}