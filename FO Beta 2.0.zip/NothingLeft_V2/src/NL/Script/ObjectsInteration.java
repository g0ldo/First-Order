package NL.Script;

import static java.awt.Color.black;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ObjectsInteration {
    
    public void leva1(JLabel Player, int deltaX, int deltaY, JLabel bottone, boolean pressE, JPanel JP1, ArrayList<JLabel> muriTemporanei){
        
        int controlloAccendi = 0;
        
        if (bottone.getBounds().intersects(deltaX, deltaY, Player.getWidth(), Player.getHeight()) && controlloAccendi == 0) {
                    
                if(pressE == true && controlloAccendi == 0){            
                    
                    bottone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverON_13.png")));

                    controlloAccendi = 1;
                    
                }
        }
        
        if (controlloAccendi == 1) {
            
            // Imposta l'icona per gli elementi nell'intervallo [8, 9]
            for (int i = 0; i < 3; i++) {
                
                if (i < muriTemporanei.size()) {
                    
                    muriTemporanei.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Erba_0.png")));
                }
            }

            // Rimuovi gli elementi dall'indice 1 all'indice 2 (escluso)
            for (int i = 0; i < 2; i++) {
                
                if (i < muriTemporanei.size()) {
                    
                    muriTemporanei.remove(i);
                }
            }
        }
        
    }
    
    public int vitaMeno(int puntiVita, boolean pausa, JLabel vita1, JLabel vita2, JLabel vita3, JLabel vita4, JLabel vita5, JLabel vuoto1, JLabel vuoto2, JLabel vuoto3, JLabel vuoto4, JLabel vuoto5, JLabel faccia, JPanel morte){
        
        puntiVita = puntiVita - 1;
        
        switch(puntiVita){
            
            case 4:
                
                vuoto5.setVisible(true);
                vita5.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia1.gif")));
                
                break;
                
            case 3:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia2.gif")));
                
                break;
                
            case 2:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia3.gif")));
                
                break;
                
            case 1:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vuoto2.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                vita2.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia4.gif")));
                
                break;
                
            case 0:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vuoto2.setVisible(true);
                vuoto1.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                vita2.setVisible(false);
                vita1.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia5.png")));
                morte.setVisible(true);
                pausa = true;
                
                break;
            
        }
        return puntiVita;
    }
    
    public int vitaPiu(int puntiVita, boolean pausa, JLabel vita1, JLabel vita2, JLabel vita3, JLabel vita4, JLabel vita5, JLabel vuoto1, JLabel vuoto2, JLabel vuoto3, JLabel vuoto4, JLabel vuoto5, JLabel faccia, JPanel morte){
        
        puntiVita = puntiVita + 1;
        
        switch(puntiVita){
            
            case 5:
                
                vuoto5.setVisible(false);
                vita5.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia0.gif")));
                
                break;
                
            case 4:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia1.gif")));
                
                break;
                
            case 3:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vuoto3.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                vita3.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia2.gif")));
                
                break;
                
            case 2:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vuoto3.setVisible(false);
                vuoto2.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                vita3.setVisible(true);
                vita2.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia3.gif")));
                
                break;
            /*  
            case 1:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vuoto3.setVisible(false);
                vuoto2.setVisible(false);
                vuoto1.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                vita3.setVisible(true);
                vita2.setVisible(true);
                vita1.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia4.gif")));
                
                break;
            */
        }
        return puntiVita;
    }
    
    
}
