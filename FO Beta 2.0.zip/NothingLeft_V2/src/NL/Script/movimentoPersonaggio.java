package NL.Script;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class movimentoPersonaggio {
    
    // Funzione per la gestione del movimento XY
    public void muoviLabel(boolean pausa, JPanel JP1, JPanel vita, JPanel settings, JLabel JL1, int deltaX, int deltaY, JLabel indicator, JPanel morte) {
        
        if(pausa == false){
            
            JP1.setLocation(JP1.getX() - deltaX, JP1.getY() - deltaY);
            JL1.setLocation(JL1.getX() + deltaX, JL1.getY() + deltaY);
        
            vita.setLocation(vita.getX() + deltaX, vita.getY() + deltaY);
            settings.setLocation(settings.getX() + deltaX, settings.getY() + deltaY);
            indicator.setLocation(indicator.getX() + deltaX, indicator.getY() + deltaY);
            morte.setLocation(morte.getX() + deltaX, morte.getY() + deltaY);
        }
        
    }
}
