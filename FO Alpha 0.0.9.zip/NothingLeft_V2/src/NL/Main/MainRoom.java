package NL.Main;

import NL.Script.generazioneTerreno;
import NL.Script.movimentoPersonaggio;
import NL.Script.puoiMuovere;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MainRoom extends javax.swing.JFrame{
    private static final String nomeGioco = "Nothing Left";
    private int step = 10; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    private int i;
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    generazioneTerreno terreno = new generazioneTerreno();
    movimentoPersonaggio personaggio = new movimentoPersonaggio();
    puoiMuovere movimento = new puoiMuovere();
    
    private boolean isWPressed = false;
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    
    private ArrayList<JLabel> muri = new ArrayList<>();
    
    public MainRoom() {
        initComponents();
        
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle(nomeGioco);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setSize(800, 800);
        
        //jPanel1.setLocation(-20, -20);
        
        terreno.generaTerreno(jPanel1, muri);
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed && movimento.canMove(Player, 0, -step, muri)) {
                    personaggio.muoviLabel(jPanel1, Player, 0, -step);
                }
                if (isSPressed && movimento.canMove(Player, 0, step, muri)) {

                    personaggio.muoviLabel(jPanel1, Player, 0, step);
                }
                if (isAPressed && movimento.canMove(Player, -step, 0, muri)) {
   
                    personaggio.muoviLabel(jPanel1, Player, -step, 0);
                }
                if (isDPressed && movimento.canMove(Player, step, 0, muri)) {

                    personaggio.muoviLabel(jPanel1, Player, step, 0);
                }
            }
        });   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Player = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setPreferredSize(new java.awt.Dimension(640, 640));
        setSize(new java.awt.Dimension(1000, 800));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png"))); // NOI18N
        Player.setBorder(new javax.swing.border.MatteBorder(null));
        Player.setPreferredSize(new java.awt.Dimension(70, 70));
        jPanel1.add(Player);
        Player.setBounds(470, 320, 60, 70);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 3500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 2500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private class KeyHandler implements KeyListener {
        Timer T1 = new Timer (100, new ActionListener() { // W
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T2 = new Timer (100, new ActionListener() { // S
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T3 = new Timer (100, new ActionListener() { // A
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_1.png")));
                        break;
                        
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_2.png")));
                        break;
                        
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T4 = new Timer (100, new ActionListener() { // D
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_1.png")));
                        break;

                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_2.png")));
                        break;
                    
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            // Ogni numero di fianco all'evento corrisponde al suo codice di animazione
            switch (keyCode) {
                case KeyEvent.VK_W: // 1
                    isWPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T1.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T1.start();
                    } else {
                        T1.start();
                    }
                    
                    break;

                case KeyEvent.VK_S: // 2
                    isSPressed = true;
                    
                    if(isAPressed) {
                        T3.stop();
                        T2.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T2.start();
                    } else {
                        T2.start();
                    }
                    
                    break;

                case KeyEvent.VK_A: // 3
                    isAPressed = true;
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T3.start();
                    }
                    
                    break;
                    
                case KeyEvent.VK_D: // 4
                    isDPressed = true; 
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T4.start();
                    }
                    
                    break;
            }
            
            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    T1.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_fermo.png")));
                    break;
                    
                case KeyEvent.VK_S:
                    isSPressed = false;
                    T2.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png")));
                    break;
                    
                case KeyEvent.VK_A:
                    isAPressed = false;
                    T3.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_fermo.png")));
                    break;
                    
                case KeyEvent.VK_D:
                    isDPressed = false;
                    T4.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_fermo.png")));
                    break;
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed) {
                // Se nessun tasto WASD è premuto, ferma il timer
                timer.stop();
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Player;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}