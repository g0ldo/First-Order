package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class generazioneTerreno {
    
    private final int maxCol = 70, maxRig = 40, tileSize = 49;
    private int mappa[][] = new int[maxRig][maxCol];
    private String riga[];
    private int i, j, xi = 0, yi = 0, num;
    private int rig = 0, col = 0;
    private javax.swing.JPanel jPanel1;
    private String line;
    
    leggiFile caricaMappa = new leggiFile("/Textures/Tiles/mappa.txt");

    public void generaTerreno(JPanel JP1, ArrayList muri) {
        
        while(col < maxCol && rig < maxRig){
            
            line = caricaMappa.leggiRiga();
            
            while(col < maxCol){
                
                String riga[] = line.split(" ");
                num = Integer.parseInt(riga[col]);
                 
                mappa[rig][col] = num;
                col++;
            }
            
            if(col == maxCol){
                col = 0;
                rig++;
            }
        }
        
        caricaMappa.chiudi();
        
        
        for(i=0; i < maxRig; i++) {
            for(j=0; j< maxCol; j++) {
                
                JLabel jLabel = new javax.swing.JLabel();
                
                //con lo switch da' problemi
                if(mappa[i][j] == 0){

                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Erba_0.png"))); 
                }
                if(mappa[i][j] == 1){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Albero_1.png")));
                    muri.add(jLabel); 
                    
                }
                if(mappa[i][j] == 2){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Montagna_2.png")));
                    muri.add(jLabel);
                    
                }
                if(mappa[i][j] == 3){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_3.png"))); 
                    
                }
                if(mappa[i][j] == 4){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_4.png")));
                    
                }
                if(mappa[i][j] == 5){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_5.png"))); 
                    
                }
                if(mappa[i][j] == 6){
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_6.png"))); // NOI18N
                    
                }
                
                jLabel.setBorder(new javax.swing.border.MatteBorder(null));
                jLabel.setOpaque(true);
                JP1.add(jLabel);
                jLabel.setBounds(xi, yi, tileSize, tileSize);
                jLabel.setVisible(true);
                
                xi = xi + tileSize;
                
            }
            xi = 0;
            yi = yi + tileSize;

        }
    }
}
