package NL.Script;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class movimentoPersonaggio {
    
    // Funzione per la gestione del movimento XY
    public void muoviLabel(JPanel JP1, JLabel JL1, int deltaX, int deltaY) {  
        
        
        JP1.setLocation(JP1.getX() - deltaX, JP1.getY() - deltaY);
        JL1.setLocation(JL1.getX() + deltaX, JL1.getY() + deltaY);
        
        //per ogni if mettere due png che si alternano ogni mezzo secondo per far sembrare il movimento del personaggio
    }
}
