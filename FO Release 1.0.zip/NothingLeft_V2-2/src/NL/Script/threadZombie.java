package NL.Script;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/*
class zT extends Thread {
    private JLabel zombie;
    
    public void run() {
        System.out.println("Thread attivo");
        
        while (true) {
            Point location = zombie.getLocation();
            location.x += 10;
            SwingUtilities.invokeLater(() -> zombie.setLocation(location));

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}*/

// Inseguimento = passa le coordinate precedenti del player

public class threadZombie {
    
    
    private int direction = 1, dir2 = 1, passi = 50; // 1 per andare avanti, -1 per tornare indietro
    private int movedDistance1 = 0, movedDistance2 = 0;
    private Timer timer1, timer2;
    private int newX, newmX;

    
    
    
    // 1 = Destra e sinistra
    public void muoviZombie(JLabel zombie0, JLabel zombie1, JLabel zombie2, JLabel zombie3, JLabel zombie4, JLabel zombie5) {
        //pV = puntiVita;
        
        timer1 = new Timer(75, new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                

                    // Muovi lo zombie 
                    newX = zombie0.getX() + (passi * direction);
                    newmX = zombie1.getX() - (passi * direction);

                    //System.out.println(newmX);
                    
                    zombie0.setLocation(newX, zombie0.getY());
                    zombie2.setLocation(newX, zombie2.getY());
                    zombie4.setLocation(newX, zombie4.getY());
                    
                    zombie1.setLocation(newmX, zombie1.getY());
                    zombie3.setLocation(newmX, zombie3.getY());
                    zombie5.setLocation(newmX, zombie5.getY());
                    
                    movedDistance1 = movedDistance1 + passi;
                    

                    // Se lo zombie ha percorso 100 unità, cambia direzione
                    if (movedDistance1 >= 790) {
                        
                        direction *= -1; // Cambia direzione
                        
                        movedDistance1 = 0; // Resetta la distanza percorsa
                    } else if(direction == 1) { 
                        zombie0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                        zombie1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                        zombie2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                        zombie3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                        zombie4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                        zombie5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                } else if(direction == -1) {
                    zombie0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                        zombie1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                        zombie2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                        zombie3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                        zombie4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_a.gif")));
                        zombie5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_d.gif")));
                }
            }
        });
    }
    
    // 2 = Alto a basso
    public void muoviZombie2(JLabel zombie6) {
        
        timer2 = new Timer(75, new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if (timer2.isRunning()) {
                    
                    int newY6 = zombie6.getY() + (passi * dir2);

                    zombie6.setLocation(zombie6.getX(), newY6);

                    movedDistance2 += passi;

                    // Se lo zombie ha percorso 100 unità, cambia direzione
                    if (movedDistance2 >= 1200) {
                        dir2 *= -1; // Cambia direzione
                        movedDistance2 = 0; // Resetta la distanza percorsa
                    } else if(direction == 1) { 
                        zombie6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_s.gif")));
                } else if(direction == -1) {
                    zombie6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Zombie/zombie_w.gif")));
                }
                    
                    
                }
            }
        });
        
    }
    
    public void movimento(boolean pausa) {
        if (pausa) {
            timer1.stop();
            timer2.stop();
        } else {
            timer1.start();
            timer2.start();
        }
    }
    
    
}
