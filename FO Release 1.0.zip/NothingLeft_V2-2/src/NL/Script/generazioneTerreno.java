package NL.Script;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class generazioneTerreno {
    // Colonne e righe tiles
    private final int maxCol = 100, maxRig = 76, tileSize = 49;
    
    private int mappa[][] = new int[maxRig][maxCol];
    private int i, j, xi = 0, yi = 0, num;
    private int rig = 0, col = 0;
    //private javax.swing.JPanel jPanel1;
    private String line;
    
    leggiFile caricaMappa = new leggiFile("/Textures/Tiles/mappa.txt");

    public void generaTerreno(JPanel JP1, ArrayList muri, ArrayList bottoni, ArrayList<JLabel> muriTemporanei, ArrayList<JLabel> muriFuturi) {
        
        //------------------------------------------------LETTURA FILE .TXT MAPPA------------------------------------------------
        while(col < maxCol && rig < maxRig){
            
            line = caricaMappa.leggiRiga();
            
            while(col < maxCol){
                
                String riga[] = line.split(" ");
                num = Integer.parseInt(riga[col]);
                 
                mappa[rig][col] = num;
                col++;
            }
            
            if(col == maxCol){
                col = 0;
                rig++;
            }
        }
        
        caricaMappa.chiudi();
        //---------------------------------------------------------------------------------------------------------------------
        
        for(i=0; i < maxRig; i++) {
            for(j=0; j< maxCol; j++) {
                
                JLabel jLabel = new javax.swing.JLabel();
                
                //con lo switch da' problemi
                if(mappa[i][j] == 0) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Erba_0.png"))); 
                    
                }
                else if(mappa[i][j] == 1) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Albero_1.png")));
                    muri.add(jLabel); 
                    
                }
                else if(mappa[i][j] == 2) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Montagna_2.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 3) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_3.png"))); 
                    
                }
                else if(mappa[i][j] == 4) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_4.png")));
                    
                }
                else if(mappa[i][j] == 5) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_5.png"))); 
                    
                }
                else if(mappa[i][j] == 6) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Strada_6.png")));
                    
                }
                else if(mappa[i][j] == 7) {
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_3_7.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 8) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_4_8.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 9) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_5_9.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 10) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Strada_6_10.png")));
                    muri.add(jLabel);
                    
                }
                else if(mappa[i][j] == 11) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Muro_Erba_11.png")));
                    muri.add(jLabel);
                    
                }
                
                else if(mappa[i][j] == 12) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/LeverOFF_12.png")));
                    bottoni.add(jLabel);
                }
                
                else if(mappa[i][j] == 14) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_14.png")));
                    muriTemporanei.add(jLabel);
                    
                }
                else if(mappa[i][j] == 15) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_15.png")));
                }
                else if(mappa[i][j] == 16) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_16.png")));
                }
                else if(mappa[i][j] == 17) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_17.png")));
                }
                else if(mappa[i][j] == 18) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_18.png")));
                }
                else if(mappa[i][j] == 19) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_19.png")));
                }
                else if(mappa[i][j] == 20) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_20.png")));
                }
                else if(mappa[i][j] == 21) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_21.png")));
                }
                else if(mappa[i][j] == 22) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Terra_Erba_22.png")));
                }
                else if(mappa[i][j] == 23) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_23.png")));
                    muriTemporanei.add(jLabel);
                }
                else if(mappa[i][j] == 24) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_24.png")));
                    muriFuturi.add(jLabel);
                }
                else if(mappa[i][j] == 25) {
                    
                    jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_25.png")));
                    muriFuturi.add(jLabel);
                }
                
                jLabel.setBorder(new javax.swing.border.MatteBorder(null));
                jLabel.setOpaque(true);
                JP1.add(jLabel);
                jLabel.setBounds(xi, yi, tileSize, tileSize);
                jLabel.setVisible(true);
                
                xi = xi + tileSize;
                
            }
            xi = 0;
            yi = yi + tileSize;
        }
    }
}
