package NL.Script;

import java.awt.Color;
import java.awt.Container;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;


public class ObjectsInteration {
    
    boolean controlloAccendi1 = false;
    boolean controlloAccendi2 = false;
    int controlloInteragisciKetamen = 0;
    int distanzaProiettile, velocitaProiettile = 50, direction = 1, originalX, originalY;

    private String riga;
    int k = 0;
    boolean presaTanica = false;
    boolean presaBatteria = false;
    boolean consegnaTanica = false;
    boolean consegnaBatteria = false;

    
    leggiFile testoDialogo = new leggiFile("/Textures/Objects/dialogo1.txt");
    
    public boolean leva1(JLabel bottone, boolean pressE, JPanel JP1, ArrayList<JLabel> muriTemporanei, ArrayList<JLabel> muriFuturi, boolean portaRossa){
        
        if (controlloAccendi1 == false) {
                    
                if(pressE == true && controlloAccendi1 == false){            
                    //System.out.println("si");
                    bottone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverON1.png")));

                    controlloAccendi1 = true;
                    
                }
        }
        
        if (controlloAccendi1 == true) {
            
            // Imposta l'icona per gli elementi nell'intervallo
            for (int i = 3; i > 1; i--) {
                
                if(i == 3){
                    muriTemporanei.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_25.png")));
                    muriTemporanei.remove(i);
                }
                if(i == 2){
                    muriTemporanei.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_24.png")));
                    muriTemporanei.remove(i);
                }
                
            }
            
            for(int i = 0; i < 2; i++){
                
                if(i == 0){
                    
                    muriFuturi.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_14.png")));
                    muriTemporanei.add(muriFuturi.get(i));
                }
                if(i == 1){
                    
                    muriFuturi.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_23.png")));
                    muriTemporanei.add(muriFuturi.get(i));
                }
            }
            portaRossa = true;

        }
        
        return controlloAccendi1;
    }
    
    public boolean leva2(JLabel bottone, boolean pressE, JPanel JP1, ArrayList<JLabel> muriTemporanei, boolean portaBlu){
        
        if (controlloAccendi2 == false) {
                    
                if(pressE == true && controlloAccendi2 == false){            

                    bottone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverON2.png")));

                    controlloAccendi2 = true;
                    
                }
        }
        
        if (controlloAccendi2 == true) {
            
            // Imposta l'icona per gli elementi nell'intervallo
            for (int i = 1; i > -1; i--) {
                
                if(i == 1){
                    muriTemporanei.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_25.png")));
                    muriTemporanei.remove(i);
                }
                if(i == 0){
                    muriTemporanei.get(i).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Tiles/Cancello_24.png")));
                    muriTemporanei.remove(i);
                }
            }
            portaBlu = true;


        }
        
        return controlloAccendi2;
        
    }
    
    public boolean ketamen(JScrollPane dialogo, boolean pressE, JPanel JP1, JLabel keta, JTextArea dialogoTesto, boolean npcSpeaking){
        String testo;
        
        if (pressE == true) {
            
            testo = null;
            
            
            switch(controlloInteragisciKetamen){
                
                case 0:
                    
                    do {
                        
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    dialogo.setVisible(true);
                    
                    
                    break;
                    
                case 1:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                case 2:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                case 3:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                case 4:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                case 5:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                    
                case 6:
                    
                    do {
                            
                        riga = testoDialogo.leggiRiga();
                        testo = riga;
                        
                    } while(riga == "\0");
                    dialogoTesto.setText(testo);
                    dialogo.setBackground(new Color(0,0,0,170));
                    
                
                    break;
                    
                    
                case 7:
                    dialogo.setVisible(false);
                    
                    break;
                    
                default:
                    
                    if(k == 0){
                        testo = "Perche' sei ancora qua??? Muoviti!! Il pollo si sta arrostendo!!";
                        dialogoTesto.setText(testo);
                        dialogo.setBackground(new Color(0,0,0,170));
                        dialogo.setVisible(true);
                        k = 1;

                    }
                    else if(k == 1){

                        dialogo.setVisible(false);
                        k = 0;
                    }
                    break;
                    
                
            }
            controlloInteragisciKetamen++;
        }
        
        return npcSpeaking = true;
    }
    
    public int vitaMeno(int puntiVita, boolean pausa, JLabel vita1, JLabel vita2, JLabel vita3, JLabel vita4, JLabel vita5, JLabel vuoto1, JLabel vuoto2, JLabel vuoto3, JLabel vuoto4, JLabel vuoto5, JLabel faccia, JPanel morte){
        
        puntiVita = puntiVita - 1;
        
        switch(puntiVita){
            
            case 4:
                
                vuoto5.setVisible(true);
                vita5.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia1.gif")));
                
                break;
                
            case 3:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia2.gif")));
                
                break;
                
            case 2:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia3.gif")));
                
                break;
                
            case 1:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vuoto2.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                vita2.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia4.gif")));
                
                break;
                
            case 0:
                
                vuoto5.setVisible(true);
                vuoto4.setVisible(true);
                vuoto3.setVisible(true);
                vuoto2.setVisible(true);
                vuoto1.setVisible(true);
                vita5.setVisible(false);
                vita4.setVisible(false);
                vita3.setVisible(false);
                vita2.setVisible(false);
                vita1.setVisible(false);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia5.png")));
                pausa = true;
                morte.setVisible(true);
                
                
                break;
            
        }
        return puntiVita;
    }
    
    public int vitaPiu(int puntiVita, boolean pausa, JLabel vita1, JLabel vita2, JLabel vita3, JLabel vita4, JLabel vita5, JLabel vuoto1, JLabel vuoto2, JLabel vuoto3, JLabel vuoto4, JLabel vuoto5, JLabel faccia, JPanel morte){
        
        puntiVita = puntiVita + 1;
        
        switch(puntiVita){
            
            case 5:
                
                vuoto5.setVisible(false);
                vita5.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia0.gif")));
                
                break;
                
            case 4:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia1.gif")));
                
                break;
                
            case 3:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vuoto3.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                vita3.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia2.gif")));
                
                break;
                
            case 2:
                
                vuoto5.setVisible(false);
                vuoto4.setVisible(false);
                vuoto3.setVisible(false);
                vuoto2.setVisible(false);
                vita5.setVisible(true);
                vita4.setVisible(true);
                vita3.setVisible(true);
                vita2.setVisible(true);
                faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia3.gif")));
                
                break;
        }
        return puntiVita;
    }
    
    public boolean benzina(boolean pressE, JLabel Tanica, ArrayList<JLabel> oggetti, ArrayList<Integer> inventario, JScrollPane consigli, JTextArea tips, JLabel nomeOggetto2, JLabel nomeOggetto3){
        Container parent = Tanica.getParent(); // Trova il parent di batteria
        
        if (presaTanica == false && pressE == true) {         
                    
                //Tanica.setVisible(false);
                parent.remove(Tanica); // Rimuovi dal parent la batteria
                parent.validate();
                parent.repaint(); // Refresh del parent quindi jPanel (camera)
                
                presaTanica = true;  
                
                for(int j = 1; j < 3; j++){
                
                    if(inventario.get(j) == 0){
                    
                        inventario.add(j, 2);
                        oggetti.get(j).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Tanica_Inventario.png")));
                        nomeOggetto2.setText("Tanica");
                    
                        break;
                    }
                
                }
            }
        
        return presaTanica;
    }
    
    public boolean batteria(boolean pressE, JLabel batteria, ArrayList<JLabel> oggetti, ArrayList<Integer> inventario, JScrollPane consigli, JTextArea tips, JLabel nomeOggetto2, JLabel nomeOggetto3){
        Container parent = batteria.getParent(); // Trova il parent di batteria
        
        if (presaBatteria == false && pressE == true) {         
                
            
                parent.remove(batteria); // Rimuovi dal parent la batteria
                parent.validate();
                parent.repaint(); // Refresh del parent quindi jPanel (camera)
            
                presaBatteria = true;  
                
                for(int j = 1; j < 3; j++){
                
                if(inventario.get(j) == 0){
                    
                    inventario.add(j, 3);
                    oggetti.get(j).setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Batteria_Inventario.png")));
                    nomeOggetto2.setText("Batteria");
                    
                    break;
                }
            }
        }
        
        return presaBatteria;
    }
    
    
    
    public boolean macchinaTanica(boolean pressE, JLabel macchina, ArrayList<JLabel> oggetti, ArrayList<Integer> inventario, JLabel nomeOggetto1, JLabel nomeOggetto2, JLabel nomeOggetto3, JLabel jLabel3){
        
        if(pressE == true){
            
            if(presaTanica == true && consegnaTanica == false){
            
                for(int j = 1; j < 3; j++){
                    
                    if(inventario.get(j) == 2){
                        
                        oggetti.get(j).setIcon(null);
                        inventario.add(j, 0);
                        nomeOggetto2.setText(null);
                        nomeOggetto2.setVisible(false);
                        
                        jLabel3.setVisible(true);
                        nomeOggetto1.setVisible(true);
                    }
                    break;
                }
                consegnaTanica = true;
            }
        } 
        
        return consegnaTanica;
    }
    
    public boolean macchinaBatteria(boolean pressE, JLabel macchina, ArrayList<JLabel> oggetti, ArrayList<Integer> inventario, JLabel nomeOggetto1, JLabel nomeOggetto2, JLabel nomeOggetto3, JLabel jLabel3, JPanel fine, boolean pausa){
        
        if(pressE == true){
            
            if(presaBatteria == true && consegnaBatteria == false){
            
                for(int j = 1; j < 3; j++){
                    
                    if(inventario.get(j) == 3){
                        
                        oggetti.get(j).setIcon(null);
                        inventario.add(j, 0);
                        
                        nomeOggetto3.setText(null);
                        nomeOggetto3.setVisible(false);
                        
                        jLabel3.setVisible(true);
                        nomeOggetto1.setVisible(true);
                    }
                    break;
                }
                consegnaBatteria = true;
            }
            
            if(consegnaBatteria == true && consegnaTanica == true){
                
                fine.setVisible(true);
                pausa = true;
            }
            
        }  
        return consegnaBatteria;
    }
     
    /*
    public void pistolaSpara(boolean isNPressed, boolean isMPressed, boolean pausa, JLabel Player, JLabel sparo, boolean isUltimaWPressed, boolean isUltimaAPressed, boolean isUltimaSPressed, boolean isUltimaDPressed, boolean fermo, boolean isWPressed, boolean isAPressed, boolean isSPressed, boolean isDPressed){
        
        originalX = sparo.getX();
        originalY = sparo.getY();
        
        if(pausa == false && isMPressed == true){
            
            Timer timerSparo = new Timer(75, new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if(fermo == true){
                    
                    if(isUltimaWPressed == true){
                        
                        direction = 1;
                        int newY = sparo.getY() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(sparo.getY(), newY);
                    }
                    else if(isUltimaDPressed == true){
                        
                        direction = 1;
                        int newX = sparo.getX() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(newX, sparo.getY());
                    }
                    else if(isUltimaAPressed == true){
                        
                        direction = -1;
                        int newX = sparo.getX() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(newX, sparo.getY());
                    }
                    else if(isUltimaSPressed == true){
                        
                        direction = -1;
                        int newY = sparo.getY() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(sparo.getY(), newY);
                    } 
                }
                
                else{
                    
                    if(isWPressed == true){
                        
                        direction = 1;
                        int newY = sparo.getY() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(sparo.getY(), newY);
                    }
                    else if(isDPressed == true){
                        
                        direction = 1;
                        int newX = sparo.getX() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(newX, sparo.getY());
                    }
                    else if(isAPressed == true){
                        
                        direction = -1;
                        int newX = sparo.getX() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(newX, sparo.getY());
                    }
                    else if(isSPressed == true){
                        
                        direction = -1;
                        int newY = sparo.getY() + (velocitaProiettile * direction);
                        
                        sparo.setLocation(sparo.getY(), newY);
                    }
                    
                }
                
                
                if(distanzaProiettile >= 800){
                    
                    distanzaProiettile = 0;
                    sparo.setLocation(originalX, originalY);
                    
                }
                
                
            }
            });
            
        }
        
    }
    
    public void movimento(boolean pausa) {
        if (pausa) {
            timerSparo.stop();
            //timer2.stop();
        } else {
            timerSparo.start();
            //timer2.start();
        }
    }
*/

        
}
    
    
