package NL.Script;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import NL.Script.ObjectsInteration;

public class movimentoPersonaggio {
    
    ObjectsInteration interazioneOggetti = new ObjectsInteration();
    
    // Funzione per la gestione del movimento XY
    public void muoviLabel(boolean pausa, JPanel fine, JPanel JP1, JPanel vita, JPanel settings, JLabel JL1, int deltaX, int deltaY, JLabel indicator, JPanel morte, JScrollPane consigli, JTextArea tips, JLabel leva1, JLabel leva2, JLabel keta, JLabel benzina, JLabel batteria, JLabel macchina, boolean tutorial, boolean presaTanica, boolean presaBatteria, boolean tirataLeva1, boolean tirataLeva2, boolean npcSpeaking, boolean consegnaTanica, boolean consegnaBatteria, int nascostoTanica, int nascostoBatteria, boolean portaRossa, boolean portaBlu) {
        
        if(pausa == false) {
            JP1.setLocation(JP1.getX() - deltaX, JP1.getY() - deltaY);
            JL1.setLocation(JL1.getX() + deltaX, JL1.getY() + deltaY);
        
            vita.setLocation(vita.getX() + deltaX, vita.getY() + deltaY);
            settings.setLocation(settings.getX() + deltaX, settings.getY() + deltaY);
            morte.setLocation(morte.getX() + deltaX, morte.getY() + deltaY);
            fine.setLocation(fine.getX() + deltaX, fine.getY() + deltaY);
            indicator.setLocation(indicator.getX() + deltaX, indicator.getY() + deltaY);
            indicator.setText("DEVELOPER X: " + JL1.getX() + "; Y: " + JL1.getY() + ";");
            consigli.setLocation(consigli.getX() + deltaX, consigli.getY() + deltaY);
            
            if(tutorial == false){
                
                if(leva1.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                
                    if(tirataLeva1 == false){
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Premi E per interagire");
                    }
                
                }
                else if(leva2.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                    
                    if(tirataLeva2 == false){
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        
                        consigli.setVisible(true);
                        tips.setText("Premi E per interagire");
                    }
                }
                else if(keta.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                
                    if(npcSpeaking == false){
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Premi E per interagire");
                    }
                    
                }
                else if(benzina.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                
                    if(presaTanica == false){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Premi E per raccogliere");
                    }
                }
                else if(batteria.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                    
                    if(presaBatteria == false){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Premi E per raccogliere");
                    }
                }
                else if(macchina.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
                    
                    if(presaBatteria == false && presaTanica == false){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Ti serve una tanica di benzina e una batteria per auto per andartene");
                    }
                    else if(presaBatteria == false && presaTanica == true){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        
                        if(consegnaTanica == true){
                            tips.setText("Ti serve una batteria per auto per andartene");
                        }
                        else{
                            
                            tips.setText("Premi E per inserire la benzina");
                        }
                    }
                    else if(presaBatteria == true && presaTanica == false){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        
                        if(consegnaBatteria == true){
                            tips.setText("Ti serve una tanica di benzina per andartene");
                        }
                        else{
                            
                            tips.setText("Premi E per inserire la batteria");
                        }
                    }
                    else{
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Premi E per andartene");
                    }
                    
                }
                else if(JL1.getBounds().intersects(2165, 3306, 60, 60)){
                    
                    if(portaRossa == false){
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Serve una leva rossa per aprire questo cancello");
                    }
                    
                }
                else if(JL1.getBounds().intersects(2221, 1818, 60, 60)){
                    
                    if(portaBlu == false){
                        
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Serve una leva blu per aprire questo cancello");
                    }
                }
                
                else{
                    
                    consigli.setVisible(false);
                }
                
                if(presaTanica == true && nascostoTanica <= 1){
                    
                        consigli.setBackground(new Color(0,0,0,170));
                        consigli.setVisible(true);
                        tips.setText("Torna alla macchina\n(Premi E per chiudere questo messaggio)");
                }
                
                if(presaBatteria == true && nascostoBatteria <= 1){
                    
                    consigli.setBackground(new Color(0,0,0,170));
                    consigli.setVisible(true);
                    tips.setText("Torna alla macchina\n(Premi E per chiudere questo messaggio)");
                }
            }
        }
    }  
    
    public int contattoZombie(JLabel JL1, JLabel zombie0, JLabel zombie1, JLabel zombie2, JLabel zombie3, JLabel zombie4, JLabel zombie5, JLabel zombie6, int puntiVita, boolean pausa, JLabel vita1, JLabel vita2, JLabel vita3, JLabel vita4, JLabel vita5, JLabel vuoto1, JLabel vuoto2, JLabel vuoto3, JLabel vuoto4, JLabel vuoto5, JLabel faccia, JPanel morte){
        
        if(pausa == false){
            
            if(zombie0.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie1.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie2.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie3.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie4.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie5.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight()) ||
            zombie6.getBounds().intersects(JL1.getX(), JL1.getY(), JL1.getWidth(), JL1.getHeight())){
            
            puntiVita = interazioneOggetti.vitaMeno(puntiVita, pausa, vita1, vita2, vita3, vita4, vita5, vuoto1, vuoto2, vuoto3, vuoto4, vuoto5, faccia, morte);
            
            }
        }
        
        return puntiVita;
    }
}