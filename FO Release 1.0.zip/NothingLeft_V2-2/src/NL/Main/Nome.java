package NL.Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.Timer;

public class Nome extends javax.swing.JFrame {
    
    private String nome;
    private int volte = 0;
    
    public Nome() {
        initComponents();
    
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle("Selezione del Nome");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        errore.setVisible(false);
        
        
    }

    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        errore = new javax.swing.JLabel();
        benvenuto = new javax.swing.JLabel();
        nomeField = new javax.swing.JTextField();
        comeTiChiami = new javax.swing.JLabel();
        confermaButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        errore.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        errore.setForeground(new java.awt.Color(255, 0, 0));
        errore.setText("Errore: devi inserire un nome da 1 a 15 caratteri");
        jPanel1.add(errore);
        errore.setBounds(20, 130, 320, 18);

        benvenuto.setFont(new java.awt.Font("Simplex_IV50", 0, 24)); // NOI18N
        benvenuto.setForeground(new java.awt.Color(255, 255, 255));
        benvenuto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(benvenuto);
        benvenuto.setBounds(10, 130, 530, 75);

        nomeField.setBackground(new java.awt.Color(0, 0, 0));
        nomeField.setForeground(new java.awt.Color(255, 255, 255));
        nomeField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel1.add(nomeField);
        nomeField.setBounds(10, 90, 440, 30);

        comeTiChiami.setFont(new java.awt.Font("Simplex_IV50", 0, 30)); // NOI18N
        comeTiChiami.setForeground(new java.awt.Color(255, 255, 255));
        comeTiChiami.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        comeTiChiami.setText("Come ti chiami?");
        jPanel1.add(comeTiChiami);
        comeTiChiami.setBounds(10, 10, 530, 75);

        confermaButton.setBackground(new java.awt.Color(0, 0, 0));
        confermaButton.setForeground(new java.awt.Color(255, 255, 255));
        confermaButton.setText("OK");
        confermaButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        confermaButton.setBorderPainted(false);
        confermaButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        confermaButton.setFocusPainted(false);
        confermaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confermaButtonActionPerformed(evt);
            }
        });
        jPanel1.add(confermaButton);
        confermaButton.setBounds(460, 90, 80, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confermaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confermaButtonActionPerformed
        
            String testo;

            nome = this.nomeField.getText();
        
            if(nome.length() > 15 || nome.length() == 0){
            
                errore.setVisible(true);
                nomeField.setText("");
            } 
            else{
            
                if(volte == 0){
                    
                    volte++;
                    errore.setVisible(false);
                    testo = "Benvenuto, " + nome;
        
                    for (int i = 0; i < testo.length(); i++) {
            
                        final int index = i;
                
                        Timer timer2 = new Timer(100 * i, new ActionListener() {
                        @Override
                
                        public void actionPerformed(ActionEvent e) {
                    
                            benvenuto.setText(testo.substring(0, index + 1));
                        }
                    });
    
                    timer2.setRepeats(false);
                    timer2.start();
                }
        
            Timer closeTimer = new Timer(5000, new ActionListener() {
            @Override
            
            public void actionPerformed(ActionEvent e) {
                JFrame mainRoom = new MainRoom(nome);
                mainRoom.setVisible(true);
                mainRoom.setLocationRelativeTo(null);
                setVisible(false);
            }
            });
    
            closeTimer.setRepeats(false);
            closeTimer.start();
        }
        
        }
        

    }//GEN-LAST:event_confermaButtonActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel benvenuto;
    private javax.swing.JLabel comeTiChiami;
    private javax.swing.JButton confermaButton;
    private javax.swing.JLabel errore;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nomeField;
    // End of variables declaration//GEN-END:variables
}
