// ********************************************************************************************************
// *  ________  __                        __             ______                   __                      * 
// * /        |/  |                      /  |           /      \                 /  |                     * 
// * $$$$$$$$/ $$/   ______    _______  _$$ |_         /$$$$$$  |  ______    ____$$ |  ______    ______   * 
// * $$ |__    /  | /      \  /       |/ $$   |        $$ |  $$ | /      \  /    $$ | /      \  /      \  * 
// * $$    |   $$ |/$$$$$$  |/$$$$$$$/ $$$$$$/         $$ |  $$ |/$$$$$$  |/$$$$$$$ |/$$$$$$  |/$$$$$$  | * 
// * $$$$$/    $$ |$$ |  $$/ $$      \   $$ | __       $$ |  $$ |$$ |  $$/ $$ |  $$ |$$    $$ |$$ |  $$/  * 
// * $$ |      $$ |$$ |       $$$$$$  |  $$ |/  |      $$ \__$$ |$$ |      $$ \__$$ |$$$$$$$$/ $$ |       * 
// * $$ |      $$ |$$ |      /     $$/   $$  $$/       $$    $$/ $$ |      $$    $$ |$$       |$$ |       * 
// * $$/       $$/ $$/       $$$$$$$/     $$$$/         $$$$$$/  $$/        $$$$$$$/  $$$$$$$/ $$/        * 
// ********************************************************************************************************


package NL.Main;

import NL.Script.ObjectsInteration;
import NL.Script.generazioneTerreno;
import NL.Script.movimentoPersonaggio;
import NL.Script.puoiMuovere;
import NL.Script.threadZombie;
import NL.Main.Nome;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

// X = 2734
// Y = 962
// coordinate benzina

// X = 4358
// Y = 962
// coordinate batteria

//X = 2165
//Y = 3306
//coordinate porta chiusa sud


//3937171701 -- che zanzaroso che sei

public class MainRoom extends javax.swing.JFrame{
    private final String nomeGioco = "Nothing Left";
    private final int step = 8; // Variabile per ogni passo compiuto, aumentando si andra piu veloci e diminuendo piu lenti
    private int i;
    private int puntiVita = 5, pt;
    
    
    private Timer timer; // Timer serve per rendere l'operazione continua durante la pressione sui tasti
    
    
    NothingLeft menuIniziale = new NothingLeft();
    generazioneTerreno terreno = new generazioneTerreno();
    movimentoPersonaggio personaggio = new movimentoPersonaggio();
    puoiMuovere movimento = new puoiMuovere();
    ObjectsInteration interazioneOggetti = new ObjectsInteration();
    threadZombie zombieT = new threadZombie();
    
    private boolean isWPressed = false; 
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    private boolean isEPressed = false; 
    //private boolean isMPressed = false;     //spara
    //private boolean isNPressed = false;     //ricarica
    
    /*
    private boolean isUltimaWPressed = false; 
    private boolean isUltimaAPressed = false;
    private boolean isUltimaSPressed = false;
    private boolean isUltimaDPressed = false;
    private boolean fermo = false;
    */

    private boolean Developer = false; //creativa goliardica per developerzzzz
    private boolean pausa = false;
    
    private boolean tutorial = true;
    private boolean presaTanica = false;
    private boolean presaBatteria = false;
    private boolean tirataLeva1 = false;
    private boolean tirataLeva2 = false;
    private boolean npcSpeaking = false;
    private boolean portaRossa = false;
    private boolean portaBlu = false;
    
    private int nascostoTanica = 0;
    private int nascostoBatteria = 0;
    
    boolean consegnaTanica = false;
    boolean consegnaBatteria = false;
    
    private ArrayList<JLabel> muri = new ArrayList<>();
    private ArrayList<JLabel> muriTemporanei = new ArrayList<>();
    private ArrayList<JLabel> bottoni = new ArrayList<>();
    private ArrayList<JLabel> muriFuturi = new ArrayList<>();
    private ArrayList<JLabel> oggetti = new ArrayList<>();
    
    private ArrayList<Integer> inventario = new ArrayList<>(3);
    
    
    public MainRoom(String nome) {
        initComponents();
        
        setLayout(null);
        labelDev.setVisible(false);
        this.setResizable(false); // Per tenere la finestra di una dimensione fissa
        this.setTitle("Caricamento in corso...");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(1000,800);
        this.setLocationRelativeTo(null);
        
        settings.setVisible(false);
        settings.setOpaque(true);
        settings.setBackground(new Color(0,0,0,130));
        
        morte.setVisible(false);
        morte.setOpaque(true);
        morte.setBackground(new Color(0,0,0,130));
        
        fine.setVisible(false);
        fine.setOpaque(true);
        fine.setBackground(new Color(0,0,0,130));
        
        barraVita.setBackground(new Color(0,0,0));
        
        terreno.generaTerreno(camera, muri, bottoni, muriTemporanei, muriFuturi);
        this.setTitle(nomeGioco);
        
        bottoni.add(levaOFF2);
        muri.add(camper);
        
        pausa = false;
        zombieT.muoviZombie(zombie0, zombie1, zombie2, zombie3, zombie4, zombie5);
        zombieT.muoviZombie2(zombie6);
        
        zombieT.movimento(pausa);
        
        addKeyListener(new KeyHandler());
        setFocusable(true); 
        
        menuIniziale.setVisible(false);
        
        dialogo.setBackground(new Color(0,0,0,170));
        dialogo.setVisible(false);
        
        consigli.setBackground(new Color(0,0,0,170));
        consigli.setVisible(true);
        tips.setText("Premere i tasti:\n- W per muoversi in su'\n- A per muoversi a sinistra\n- S per muoversi giu'\n- D per muoversi a destra\n- ESC per mettere il gioco in pausa\n(Premere il tasto E per chiudere questo messaggio)");
        
        this.playerName.setText(nome);
        inventario.add(0, 0);
        inventario.add(1, 0);
        inventario.add(2, 0);
        
        inventario.add(0, 1);
        oggetto1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Pistola.png")));
     
        oggetti.add(oggetto1);
        oggetti.add(oggetto2);
        oggetti.add(oggetto3);
        
        nomeOggetto1.setText("Pistola");
        jLabel3.setVisible(true);
        nomeOggetto1.setVisible(true);
        
        nomeOggetto2.setVisible(false);
        jLabel4.setVisible(false);
        nomeOggetto3.setVisible(false);
        jLabel5.setVisible(false);
        
        warning.setVisible(true);
        
        pt = puntiVita;
     
        
        timer = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                // Azione continua durante il timer
                if (isWPressed && movimento.canMove(Player, 0, -step, muri, levaOFF2, isEPressed, camera, Developer, muriTemporanei)) {

                    personaggio.muoviLabel(pausa, fine, camera, barraVita, settings, Player, 0, -step, labelDev, morte, consigli, tips, levaOFF1, levaOFF2, npcKetamen, tanica, batteria, macchina, tutorial, presaTanica, presaBatteria, tirataLeva1, tirataLeva2, npcSpeaking, consegnaTanica, consegnaBatteria, nascostoTanica, nascostoBatteria, portaRossa, portaBlu);
                
                }
                if (isSPressed && movimento.canMove(Player, 0, step, muri, levaOFF2, isEPressed, camera, Developer, muriTemporanei)) {
                    
                    personaggio.muoviLabel(pausa, fine, camera, barraVita, settings, Player, 0, step, labelDev, morte, consigli, tips, levaOFF1, levaOFF2, npcKetamen, tanica, batteria, macchina, tutorial, presaTanica, presaBatteria, tirataLeva1, tirataLeva2, npcSpeaking, consegnaTanica, consegnaBatteria, nascostoTanica, nascostoBatteria, portaRossa, portaBlu);
                
                }
                if (isAPressed && movimento.canMove(Player, -step, 0, muri, levaOFF2, isEPressed, camera, Developer, muriTemporanei)) {
   
                    personaggio.muoviLabel(pausa, fine, camera, barraVita, settings, Player, -step, 0, labelDev, morte, consigli, tips, levaOFF1, levaOFF2, npcKetamen, tanica, batteria, macchina, tutorial, presaTanica, presaBatteria, tirataLeva1, tirataLeva2, npcSpeaking, consegnaTanica, consegnaBatteria, nascostoTanica, nascostoBatteria, portaRossa, portaBlu);
                
                }
                if (isDPressed && movimento.canMove(Player, step, 0, muri, levaOFF2, isEPressed, camera, Developer, muriTemporanei)) {

                    personaggio.muoviLabel(pausa, fine, camera, barraVita, settings, Player, step, 0, labelDev, morte, consigli, tips, levaOFF1, levaOFF2, npcKetamen, tanica, batteria, macchina, tutorial, presaTanica, presaBatteria, tirataLeva1, tirataLeva2, npcSpeaking, consegnaTanica, consegnaBatteria, nascostoTanica, nascostoBatteria, portaRossa, portaBlu);
                   
                
                }
                
            }
            
        }); 
        
    Timer timerVita = new Timer(1, null);
    
    Timer timerPausa = new Timer(500, new ActionListener() {
        
    @Override
    public void actionPerformed(ActionEvent e) {
        timerVita.start();
        ((Timer)e.getSource()).stop();
    }
    });

    timerVita.addActionListener(new ActionListener() {
        
    @Override
    public void actionPerformed(ActionEvent e) {
        
        puntiVita = personaggio.contattoZombie(Player, zombie0, zombie1, zombie2, zombie3, zombie4, zombie5, zombie6, puntiVita, pausa, vita1, vita2, vita3, vita4, vita5, vuoto1, vuoto2, vuoto3, vuoto4, vuoto5, faccia, morte);
        //System.out.println(puntiVita);

        if (pt != puntiVita) {
            
            pt = puntiVita;
            timerVita.stop();
            timerPausa.start();
            }
        }
    });

    timerVita.start();
    timerVita.setRepeats(true);
    timerPausa.setRepeats(false);
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        camera = new javax.swing.JPanel();
        labelDev = new javax.swing.JLabel();
        settings = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        RiprendiButton = new javax.swing.JButton();
        DeveloperButton = new javax.swing.JButton();
        EsciButton = new javax.swing.JButton();
        morte = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        RigiocaButton = new javax.swing.JButton();
        EsciButton1 = new javax.swing.JButton();
        fine = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        RigiocaButton1 = new javax.swing.JButton();
        EsciButton2 = new javax.swing.JButton();
        consigli = new javax.swing.JScrollPane();
        tips = new javax.swing.JTextArea();
        barraVita = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        playerName = new javax.swing.JLabel();
        oggetto1 = new javax.swing.JLabel();
        oggetto2 = new javax.swing.JLabel();
        oggetto3 = new javax.swing.JLabel();
        vita2 = new javax.swing.JLabel();
        vita3 = new javax.swing.JLabel();
        vita5 = new javax.swing.JLabel();
        vita4 = new javax.swing.JLabel();
        faccia = new javax.swing.JLabel();
        vita1 = new javax.swing.JLabel();
        vuoto5 = new javax.swing.JLabel();
        vuoto1 = new javax.swing.JLabel();
        vuoto4 = new javax.swing.JLabel();
        vuoto2 = new javax.swing.JLabel();
        vuoto3 = new javax.swing.JLabel();
        nomeOggetto1 = new javax.swing.JLabel();
        nomeOggetto2 = new javax.swing.JLabel();
        nomeOggetto3 = new javax.swing.JLabel();
        dialogo = new javax.swing.JScrollPane();
        JTextArea = new javax.swing.JTextArea();
        warning = new javax.swing.JLabel();
        Player = new javax.swing.JLabel();
        levaOFF2 = new javax.swing.JLabel();
        macchina = new javax.swing.JLabel();
        camper = new javax.swing.JLabel();
        legnaFuoco = new javax.swing.JLabel();
        fuoco = new javax.swing.JLabel();
        npcKetamen = new javax.swing.JLabel();
        zombie0 = new javax.swing.JLabel();
        batteria = new javax.swing.JLabel();
        tanica = new javax.swing.JLabel();
        levaOFF1 = new javax.swing.JLabel();
        zombie1 = new javax.swing.JLabel();
        zombie2 = new javax.swing.JLabel();
        zombie3 = new javax.swing.JLabel();
        zombie4 = new javax.swing.JLabel();
        zombie5 = new javax.swing.JLabel();
        zombie6 = new javax.swing.JLabel();
        sparo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setSize(new java.awt.Dimension(1000, 800));

        camera.setBackground(new java.awt.Color(0, 0, 0));
        camera.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        camera.setLayout(null);

        labelDev.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        labelDev.setForeground(new java.awt.Color(255, 255, 255));
        labelDev.setText("DEVELOPER ");
        camera.add(labelDev);
        labelDev.setBounds(670, 40, 290, 40);

        settings.setAlignmentX(0.0F);
        settings.setAlignmentY(0.0F);
        settings.setPreferredSize(new java.awt.Dimension(1000, 800));
        settings.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Gioco in Pausa");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        settings.add(jLabel1);
        jLabel1.setBounds(300, 140, 397, 101);

        RiprendiButton.setBackground(new java.awt.Color(0, 0, 0));
        RiprendiButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RiprendiButton.setForeground(new java.awt.Color(255, 255, 255));
        RiprendiButton.setText("Riprendi");
        RiprendiButton.setFocusPainted(false);
        RiprendiButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RiprendiButtonActionPerformed(evt);
            }
        });
        settings.add(RiprendiButton);
        RiprendiButton.setBounds(360, 240, 270, 60);

        DeveloperButton.setBackground(new java.awt.Color(0, 0, 0));
        DeveloperButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        DeveloperButton.setForeground(new java.awt.Color(255, 255, 255));
        DeveloperButton.setText("DeveloperMode: OFF");
        DeveloperButton.setFocusPainted(false);
        DeveloperButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeveloperButtonActionPerformed(evt);
            }
        });
        settings.add(DeveloperButton);
        DeveloperButton.setBounds(360, 310, 270, 60);

        EsciButton.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton.setText("Esci");
        EsciButton.setFocusPainted(false);
        EsciButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButtonActionPerformed(evt);
            }
        });
        settings.add(EsciButton);
        EsciButton.setBounds(360, 380, 270, 60);

        camera.add(settings);
        settings.setBounds(0, 0, 1000, 800);

        morte.setAlignmentX(0.0F);
        morte.setAlignmentY(0.0F);
        morte.setPreferredSize(new java.awt.Dimension(1000, 800));
        morte.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Sei morto");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        morte.add(jLabel2);
        jLabel2.setBounds(300, 140, 397, 101);

        RigiocaButton.setBackground(new java.awt.Color(0, 0, 0));
        RigiocaButton.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RigiocaButton.setForeground(new java.awt.Color(255, 255, 255));
        RigiocaButton.setText("Rigioca");
        RigiocaButton.setFocusPainted(false);
        RigiocaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RigiocaButtonActionPerformed(evt);
            }
        });
        morte.add(RigiocaButton);
        RigiocaButton.setBounds(360, 240, 270, 60);

        EsciButton1.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton1.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton1.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton1.setText("Esci");
        EsciButton1.setFocusPainted(false);
        EsciButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButton1ActionPerformed(evt);
            }
        });
        morte.add(EsciButton1);
        EsciButton1.setBounds(360, 320, 270, 60);

        camera.add(morte);
        morte.setBounds(0, 0, 1000, 800);

        fine.setAlignmentX(0.0F);
        fine.setAlignmentY(0.0F);
        fine.setPreferredSize(new java.awt.Dimension(1000, 800));
        fine.setLayout(null);

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Academy Engraved LET", 0, 48)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Hai vinto");
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fine.add(jLabel6);
        jLabel6.setBounds(300, 140, 397, 101);

        RigiocaButton1.setBackground(new java.awt.Color(0, 0, 0));
        RigiocaButton1.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        RigiocaButton1.setForeground(new java.awt.Color(255, 255, 255));
        RigiocaButton1.setText("Rigioca");
        RigiocaButton1.setFocusPainted(false);
        RigiocaButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RigiocaButton1ActionPerformed(evt);
            }
        });
        fine.add(RigiocaButton1);
        RigiocaButton1.setBounds(360, 240, 270, 60);

        EsciButton2.setBackground(new java.awt.Color(0, 0, 0));
        EsciButton2.setFont(new java.awt.Font("Academy Engraved LET", 0, 24)); // NOI18N
        EsciButton2.setForeground(new java.awt.Color(255, 255, 255));
        EsciButton2.setText("Esci");
        EsciButton2.setFocusPainted(false);
        EsciButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsciButton2ActionPerformed(evt);
            }
        });
        fine.add(EsciButton2);
        EsciButton2.setBounds(360, 320, 270, 60);

        camera.add(fine);
        fine.setBounds(0, 0, 1000, 800);

        tips.setEditable(false);
        tips.setBackground(new java.awt.Color(0, 0, 0));
        tips.setColumns(20);
        tips.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        tips.setForeground(new java.awt.Color(255, 255, 255));
        tips.setLineWrap(true);
        tips.setRows(5);
        tips.setText("consigli");
        tips.setAutoscrolls(false);
        tips.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tips.setFocusTraversalKeysEnabled(false);
        tips.setFocusable(false);
        tips.setHighlighter(null);
        tips.setRequestFocusEnabled(false);
        tips.setVerifyInputWhenFocusTarget(false);
        consigli.setViewportView(tips);

        camera.add(consigli);
        consigli.setBounds(30, 30, 350, 210);

        barraVita.setBackground(new java.awt.Color(153, 153, 255));
        barraVita.setLayout(null);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Selection.png"))); // NOI18N
        barraVita.add(jLabel5);
        jLabel5.setBounds(610, 10, 85, 85);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Selection.png"))); // NOI18N
        barraVita.add(jLabel4);
        jLabel4.setBounds(520, 10, 85, 85);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Selection.png"))); // NOI18N
        barraVita.add(jLabel3);
        jLabel3.setBounds(430, 10, 85, 85);

        playerName.setFont(new java.awt.Font("Arial Black", 2, 18)); // NOI18N
        playerName.setForeground(new java.awt.Color(255, 255, 255));
        playerName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        playerName.setText("Nombreeeeeeeeee");
        barraVita.add(playerName);
        playerName.setBounds(140, 60, 240, 30);

        oggetto1.setBackground(new java.awt.Color(51, 51, 51));
        oggetto1.setOpaque(true);
        barraVita.add(oggetto1);
        oggetto1.setBounds(430, 10, 80, 80);

        oggetto2.setBackground(new java.awt.Color(51, 51, 51));
        oggetto2.setOpaque(true);
        barraVita.add(oggetto2);
        oggetto2.setBounds(520, 10, 80, 80);

        oggetto3.setBackground(new java.awt.Color(51, 51, 51));
        oggetto3.setOpaque(true);
        barraVita.add(oggetto3);
        oggetto3.setBounds(610, 10, 80, 80);

        vita2.setBackground(new java.awt.Color(255, 0, 0));
        vita2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita2);
        vita2.setBounds(190, 10, 45, 58);

        vita3.setBackground(new java.awt.Color(255, 0, 0));
        vita3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita3);
        vita3.setBounds(240, 10, 45, 58);

        vita5.setBackground(new java.awt.Color(255, 0, 0));
        vita5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita5);
        vita5.setBounds(340, 10, 47, 58);

        vita4.setBackground(new java.awt.Color(255, 0, 0));
        vita4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita4);
        vita4.setBounds(290, 10, 45, 58);

        faccia.setBackground(new java.awt.Color(0, 0, 0));
        faccia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Faccia0.gif"))); // NOI18N
        faccia.setOpaque(true);
        barraVita.add(faccia);
        faccia.setBounds(10, 10, 100, 100);

        vita1.setBackground(new java.awt.Color(255, 0, 0));
        vita1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/purpleHeart.png"))); // NOI18N
        barraVita.add(vita1);
        vita1.setBounds(140, 10, 45, 58);

        vuoto5.setBackground(new java.awt.Color(255, 0, 0));
        vuoto5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto5);
        vuoto5.setBounds(340, 10, 45, 58);

        vuoto1.setBackground(new java.awt.Color(255, 0, 0));
        vuoto1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto1);
        vuoto1.setBounds(140, 10, 45, 58);

        vuoto4.setBackground(new java.awt.Color(255, 0, 0));
        vuoto4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto4);
        vuoto4.setBounds(290, 10, 45, 58);

        vuoto2.setBackground(new java.awt.Color(255, 0, 0));
        vuoto2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto2);
        vuoto2.setBounds(190, 10, 45, 58);

        vuoto3.setBackground(new java.awt.Color(255, 0, 0));
        vuoto3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/emptyHeart.png"))); // NOI18N
        barraVita.add(vuoto3);
        vuoto3.setBounds(240, 10, 45, 58);

        nomeOggetto1.setFont(new java.awt.Font("Arial Black", 2, 12)); // NOI18N
        nomeOggetto1.setForeground(new java.awt.Color(255, 255, 255));
        nomeOggetto1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeOggetto1.setText("Oggetto1");
        nomeOggetto1.setToolTipText("");
        barraVita.add(nomeOggetto1);
        nomeOggetto1.setBounds(430, 90, 80, 20);

        nomeOggetto2.setFont(new java.awt.Font("Arial Black", 2, 12)); // NOI18N
        nomeOggetto2.setForeground(new java.awt.Color(255, 255, 255));
        nomeOggetto2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeOggetto2.setText("Oggetto2");
        nomeOggetto2.setToolTipText("");
        barraVita.add(nomeOggetto2);
        nomeOggetto2.setBounds(520, 90, 80, 18);

        nomeOggetto3.setFont(new java.awt.Font("Arial Black", 2, 12)); // NOI18N
        nomeOggetto3.setForeground(new java.awt.Color(255, 255, 255));
        nomeOggetto3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeOggetto3.setText("Oggetto3");
        nomeOggetto3.setToolTipText("");
        barraVita.add(nomeOggetto3);
        nomeOggetto3.setBounds(610, 90, 80, 18);

        camera.add(barraVita);
        barraVita.setBounds(150, 650, 700, 120);

        JTextArea.setEditable(false);
        JTextArea.setBackground(new java.awt.Color(0, 0, 0));
        JTextArea.setColumns(20);
        JTextArea.setFont(new java.awt.Font("Andale Mono", 0, 18)); // NOI18N
        JTextArea.setForeground(new java.awt.Color(255, 255, 255));
        JTextArea.setLineWrap(true);
        JTextArea.setRows(5);
        JTextArea.setText("Dialogo");
        JTextArea.setAutoscrolls(false);
        JTextArea.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.white, java.awt.Color.white), "Uomo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Helvetica Neue", 0, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        JTextArea.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        dialogo.setViewportView(JTextArea);

        camera.add(dialogo);
        dialogo.setBounds(1310, 850, 460, 240);

        warning.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Warning.png"))); // NOI18N
        camera.add(warning);
        warning.setBounds(1520, 1050, 40, 50);

        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png"))); // NOI18N
        Player.setBorder(new javax.swing.border.MatteBorder(null));
        Player.setPreferredSize(new java.awt.Dimension(70, 70));
        camera.add(Player);
        Player.setBounds(470, 370, 60, 70);

        levaOFF2.setBackground(new java.awt.Color(255, 255, 255));
        levaOFF2.setForeground(new java.awt.Color(255, 255, 255));
        levaOFF2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverOFF2.png"))); // NOI18N
        levaOFF2.setMaximumSize(new java.awt.Dimension(49, 49));
        levaOFF2.setMinimumSize(new java.awt.Dimension(49, 49));
        camera.add(levaOFF2);
        levaOFF2.setBounds(2905, 2905, 49, 49);

        macchina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Macchina.png"))); // NOI18N
        macchina.setPreferredSize(new java.awt.Dimension(100, 100));
        camera.add(macchina);
        macchina.setBounds(810, 370, 150, 70);

        camper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Camper.png"))); // NOI18N
        camera.add(camper);
        camper.setBounds(1480, 940, 250, 140);

        legnaFuoco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LegnaFuoco.png"))); // NOI18N
        camera.add(legnaFuoco);
        legnaFuoco.setBounds(1600, 1180, 40, 20);

        fuoco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/fuoco_gif.gif"))); // NOI18N
        camera.add(fuoco);
        fuoco.setBounds(1590, 1140, 50, 50);

        npcKetamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Ketamen.gif"))); // NOI18N
        camera.add(npcKetamen);
        npcKetamen.setBounds(1500, 1090, 60, 90);

        zombie0.setBackground(new java.awt.Color(255, 255, 255));
        zombie0.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie0);
        zombie0.setBounds(3150, 1000, 70, 70);

        batteria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Batteria.png"))); // NOI18N
        batteria.setText("h");
        camera.add(batteria);
        batteria.setBounds(4380, 980, 50, 50);

        tanica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/Tanica.png"))); // NOI18N
        tanica.setText("h");
        camera.add(tanica);
        tanica.setBounds(2870, 970, 50, 50);

        levaOFF1.setBackground(new java.awt.Color(255, 255, 255));
        levaOFF1.setForeground(new java.awt.Color(255, 255, 255));
        levaOFF1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Objects/LeverOFF1.png"))); // NOI18N
        levaOFF1.setMaximumSize(new java.awt.Dimension(49, 49));
        levaOFF1.setMinimumSize(new java.awt.Dimension(49, 49));
        camera.add(levaOFF1);
        levaOFF1.setBounds(2107, 2548, 49, 49);

        zombie1.setBackground(new java.awt.Color(255, 255, 255));
        zombie1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie1);
        zombie1.setBounds(3930, 1140, 70, 70);

        zombie2.setBackground(new java.awt.Color(255, 255, 255));
        zombie2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie2);
        zombie2.setBounds(3150, 1280, 70, 70);

        zombie3.setBackground(new java.awt.Color(255, 255, 255));
        zombie3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie3);
        zombie3.setBounds(3930, 1420, 70, 70);

        zombie4.setBackground(new java.awt.Color(255, 255, 255));
        zombie4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie4);
        zombie4.setBounds(3150, 1560, 70, 70);

        zombie5.setBackground(new java.awt.Color(255, 255, 255));
        zombie5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie5);
        zombie5.setBounds(3930, 1700, 70, 70);

        zombie6.setBackground(new java.awt.Color(255, 255, 255));
        zombie6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        camera.add(zombie6);
        zombie6.setBounds(4020, 1070, 70, 70);

        sparo.setBackground(new java.awt.Color(255, 255, 255));
        sparo.setForeground(new java.awt.Color(255, 255, 255));
        sparo.setOpaque(true);
        camera.add(sparo);
        sparo.setBounds(490, 400, 10, 10);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(camera, javax.swing.GroupLayout.PREFERRED_SIZE, 4900, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(camera, javax.swing.GroupLayout.PREFERRED_SIZE, 4000, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeveloperButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeveloperButtonActionPerformed
        
        if(Developer == false){
            
            labelDev.setVisible(true);
            DeveloperButton.setText("DeveloperMode: ON");
            Developer = true;
            //creativa.setVisible(true);
        }
        else{
            
            labelDev.setVisible(false);
            DeveloperButton.setText("DeveloperMode: OFF");
            Developer = false;
        }
    }//GEN-LAST:event_DeveloperButtonActionPerformed
    
    private void RiprendiButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RiprendiButtonActionPerformed
        
        pausa = false;
        zombieT.movimento(pausa);
        settings.setVisible(false);
        //puntiVita = interazioneOggetti.vitaMeno(puntiVita, pausa, vita1, vita2, vita3, vita4, vita5, vuoto1, vuoto2, vuoto3, vuoto4, vuoto5, faccia, morte);
    }//GEN-LAST:event_RiprendiButtonActionPerformed

    private void EsciButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButtonActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButtonActionPerformed

    private void EsciButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButton1ActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButton1ActionPerformed

    private void RigiocaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RigiocaButtonActionPerformed
        
        Nome game = new Nome();
        game.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RigiocaButtonActionPerformed

    private void RigiocaButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RigiocaButton1ActionPerformed
        
        Nome game = new Nome();
        game.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RigiocaButton1ActionPerformed

    private void EsciButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsciButton2ActionPerformed
        
        this.dispose();
        menuIniziale.setVisible(true);
    }//GEN-LAST:event_EsciButton2ActionPerformed
    
    
    private class KeyHandler implements KeyListener {
        Timer T1 = new Timer (100, new ActionListener() { // W
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T2 = new Timer (100, new ActionListener() { // S
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_1.png")));
                        break;
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_2.png")));
                        break;
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T3 = new Timer (100, new ActionListener() { // A
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_1.png")));
                        break;
                        
                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_2.png")));
                        break;
                        
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        Timer T4 = new Timer (100, new ActionListener() { // D
            public void actionPerformed(ActionEvent e) {

                i++;
                
                switch(i) {
                    case 1:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_1.png")));
                        break;

                        
                    case 2:
                        Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_2.png")));
                        break;
                    
                }
                
                if(i == 2) {
                    i = 0;
                }
            }
        });
        
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override // Movimento
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            // Ogni numero di fianco all'evento corrisponde al suo codice di animazione
            switch (keyCode) {
                case KeyEvent.VK_W: // 1
                    isWPressed = true;
                    //fermo = false;
                    
                    if(isAPressed) {
                        T3.stop();
                        T1.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T1.start();
                    } else {
                        T1.start();
                    }
                    
                    break;

                case KeyEvent.VK_S: // 2
                    isSPressed = true;
                    //fermo = false;
                    
                    if(isAPressed) {
                        T3.stop();
                        T2.start();
                    } else if(isDPressed) {
                        T4.stop();
                        T2.start();
                    } else {
                        T2.start();
                    }
                    
                    break;

                case KeyEvent.VK_A: // 3
                    isAPressed = true;
                    //fermo = false;
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T3.start();
                    }
                    
                    break;
                    
                case KeyEvent.VK_D: // 4
                    isDPressed = true; 
                    //fermo = false;
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    } else {
                        T4.start();
                    }
                    break;
                
                case KeyEvent.VK_E:
                    
                    isEPressed = true;
                    
                    if(levaOFF1.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        tirataLeva1 = interazioneOggetti.leva1(levaOFF1, isEPressed, camera, muriTemporanei, muriFuturi, portaRossa);
                    }
                    if(npcKetamen.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        npcSpeaking = true;
                        warning.setVisible(false);
                        npcSpeaking = interazioneOggetti.ketamen(dialogo, isEPressed, camera, npcKetamen, JTextArea, npcSpeaking);
                    }
                    if(tanica.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        presaTanica = interazioneOggetti.benzina(isEPressed, tanica, oggetti, inventario, consigli, tips, nomeOggetto2, nomeOggetto3);
                        
                    }
                    if(batteria.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        presaBatteria = interazioneOggetti.batteria(isEPressed, batteria, oggetti, inventario, consigli, tips, nomeOggetto2, nomeOggetto3);
                        
                    }
                    if(levaOFF2.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        tirataLeva2 = interazioneOggetti.leva2(levaOFF2, isEPressed, camera, muriTemporanei, portaBlu);
                    }
                    if(macchina.getBounds().intersects(Player.getX(), Player.getY(), Player.getWidth(), Player.getHeight())){
                        
                        consegnaTanica = interazioneOggetti.macchinaTanica(isEPressed, macchina, oggetti, inventario, nomeOggetto1, nomeOggetto2, nomeOggetto3, jLabel3);
                        consegnaBatteria = interazioneOggetti.macchinaBatteria(isEPressed, macchina, oggetti, inventario, nomeOggetto1, nomeOggetto2, nomeOggetto3, jLabel3, fine, pausa);
                    }
                    
                    if(presaTanica == true){
                            
                        nascostoTanica++;
                    }
                    if(presaBatteria == true){
                            
                        nascostoBatteria++;
                    }
                    
                    consigli.setVisible(false);
                    tutorial = false;
                    
                    break;
                 
                    
                case KeyEvent.VK_ESCAPE:

                    if(pausa == false){
                        
                        settings.setVisible(true);
                        pausa = true;
                        zombieT.movimento(pausa);
                    }
                    else{
                        
                        settings.setVisible(false);
                        pausa = false;
                        zombieT.movimento(pausa);
                    }
                    break;
                    
                case KeyEvent.VK_1:
                    
                    jLabel3.setVisible(true);
                    nomeOggetto1.setVisible(true);
                    
                    nomeOggetto2.setVisible(false);
                    jLabel4.setVisible(false);
                    
                    nomeOggetto3.setVisible(false);
                    jLabel5.setVisible(false);
                    
                    break;
                    
                case KeyEvent.VK_2:
                    
                    if(inventario.get(1) != 0){
                        
                        jLabel3.setVisible(false);
                        nomeOggetto1.setVisible(false);
                    
                        nomeOggetto2.setVisible(true);
                        jLabel4.setVisible(true);
                    
                        nomeOggetto3.setVisible(false);
                        jLabel5.setVisible(false);
                    }
                    break;
                    
                case KeyEvent.VK_3:
                    
                    if(inventario.get(2) != 0){
                        
                        jLabel3.setVisible(false);
                        nomeOggetto1.setVisible(false);
                    
                        nomeOggetto2.setVisible(false);
                        jLabel4.setVisible(false);
                    
                        nomeOggetto3.setVisible(true);
                        jLabel5.setVisible(true);
                    }
                    break;
            }
            
            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override // Fermo
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                
                
                case KeyEvent.VK_W:
                    isWPressed = false;
                    T1.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_w_fermo.png")));
                    /*
                    isUltimaWPressed = true;
                    isUltimaAPressed = false;
                    isUltimaSPressed = false;
                    isUltimaDPressed = false;      
                   */
                    break;
                    
                case KeyEvent.VK_S:
                    isSPressed = false;
                    T2.stop();
                    
                    if(isAPressed) {
                        T3.start();
                    } else if(isDPressed) {
                        T4.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_s_fermo.png")));
                    /*
                    isUltimaWPressed = false;
                    isUltimaAPressed = false;
                    isUltimaSPressed = true;
                    isUltimaDPressed = false;
*/
                    
                    break;
                    
                case KeyEvent.VK_A:
                    isAPressed = false;
                    T3.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_a_fermo.png")));
                    /*
                    isUltimaWPressed = false;
                    isUltimaAPressed = true;
                    isUltimaSPressed = false;
                    isUltimaDPressed = false;
*/
                    break;
                    
                case KeyEvent.VK_D:
                    isDPressed = false;
                    T4.stop();
                    
                    if(isWPressed) {
                        T1.start();
                    } else if(isSPressed) {
                        T2.start();
                    }
                    
                    Player.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Textures/Player/Player_d_fermo.png")));
                    /*
                    isUltimaWPressed = false;
                    isUltimaAPressed = false;
                    isUltimaSPressed = false;
                    isUltimaDPressed = true;
*/
                    break;
                    
                case KeyEvent.VK_E:
                    isEPressed = false;
                    break;
            
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed && !isEPressed) {
                // Se nessun tasto WASDE è premuto, ferma il timer
                //fermo = true;
                timer.stop();
            }
        }
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeveloperButton;
    private javax.swing.JButton EsciButton;
    private javax.swing.JButton EsciButton1;
    private javax.swing.JButton EsciButton2;
    private javax.swing.JTextArea JTextArea;
    private javax.swing.JLabel Player;
    private javax.swing.JButton RigiocaButton;
    private javax.swing.JButton RigiocaButton1;
    private javax.swing.JButton RiprendiButton;
    private javax.swing.JPanel barraVita;
    private javax.swing.JLabel batteria;
    private javax.swing.JPanel camera;
    private javax.swing.JLabel camper;
    private javax.swing.JScrollPane consigli;
    private javax.swing.JScrollPane dialogo;
    private javax.swing.JLabel faccia;
    private javax.swing.JPanel fine;
    private javax.swing.JLabel fuoco;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel labelDev;
    private javax.swing.JLabel legnaFuoco;
    private javax.swing.JLabel levaOFF1;
    private javax.swing.JLabel levaOFF2;
    private javax.swing.JLabel macchina;
    private javax.swing.JPanel morte;
    private javax.swing.JLabel nomeOggetto1;
    private javax.swing.JLabel nomeOggetto2;
    private javax.swing.JLabel nomeOggetto3;
    private javax.swing.JLabel npcKetamen;
    private javax.swing.JLabel oggetto1;
    private javax.swing.JLabel oggetto2;
    private javax.swing.JLabel oggetto3;
    private javax.swing.JLabel playerName;
    private javax.swing.JPanel settings;
    private javax.swing.JLabel sparo;
    private javax.swing.JLabel tanica;
    private javax.swing.JTextArea tips;
    private javax.swing.JLabel vita1;
    private javax.swing.JLabel vita2;
    private javax.swing.JLabel vita3;
    private javax.swing.JLabel vita4;
    private javax.swing.JLabel vita5;
    private javax.swing.JLabel vuoto1;
    private javax.swing.JLabel vuoto2;
    private javax.swing.JLabel vuoto3;
    private javax.swing.JLabel vuoto4;
    private javax.swing.JLabel vuoto5;
    private javax.swing.JLabel warning;
    private javax.swing.JLabel zombie0;
    private javax.swing.JLabel zombie1;
    private javax.swing.JLabel zombie2;
    private javax.swing.JLabel zombie3;
    private javax.swing.JLabel zombie4;
    private javax.swing.JLabel zombie5;
    private javax.swing.JLabel zombie6;
    // End of variables declaration//GEN-END:variables
}