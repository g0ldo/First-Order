package fgmproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class MainFrame extends javax.swing.JFrame{
    private static final String nomeGioco = "Peccatore";
    private int step = 5; // Regola la velocità del movimento
    private Timer timer;
    private boolean isWPressed = false;
    private boolean isSPressed = false;
    private boolean isAPressed = false;
    private boolean isDPressed = false;
    
    public MainFrame() {
        initComponents();
        
        this.setResizable(false);
        this.setTitle(nomeGioco);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        
        addKeyListener(new KeyHandler());
        setFocusable(true);
        
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Azione continua durante il timer
                if (isWPressed) {
                    moveLabel(0, -step);
                }
                if (isSPressed) {
                    moveLabel(0, step);
                }
                if (isAPressed) {
                    moveLabel(-step, 0);
                }
                if (isDPressed) {
                    moveLabel(step, 0);
                }
            }
        });
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setBorder(new javax.swing.border.MatteBorder(null));
        jLabel1.setOpaque(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(446, 446, 446)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(528, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(319, 319, 319)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(399, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private class KeyHandler implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = true;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = true;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = true;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = true;
                    break;
            }

            if (!timer.isRunning()) {
                timer.start();
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            int keyCode = e.getKeyCode();

            switch (keyCode) {
                case KeyEvent.VK_W:
                    isWPressed = false;
                    break;
                case KeyEvent.VK_S:
                    isSPressed = false;
                    break;
                case KeyEvent.VK_A:
                    isAPressed = false;
                    break;
                case KeyEvent.VK_D:
                    isDPressed = false;
                    break;
            }

            if (!isWPressed && !isSPressed && !isAPressed && !isDPressed) {
                // Se nessun tasto WASD è premuto, ferma il timer
                timer.stop();
            }
        }
    }
    
    private void moveLabel(int deltaX, int deltaY) {
        jLabel1.setLocation(jLabel1.getX() + deltaX, jLabel1.getY() + deltaY);
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

}
