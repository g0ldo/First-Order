/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filemanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author lucamazzi
 */
public class FileTestoInput {
    
    private String nome;
    private Scanner inputStream;

    public FileTestoInput(String nome) {
        this.nome = nome;

        try {
            this.inputStream = new Scanner(new File(nome));
        } catch (FileNotFoundException var3) {
            System.out.println("errore nell'apertura del file" + nome);
            System.exit(0);
        }

    }

    public String leggiRiga() {
        String riga = this.inputStream.nextLine();
        return riga;
    }

    public String getNome() {
        return this.nome;
    }

    public boolean isNotEoF() {
        return this.inputStream.hasNextLine();
    }

    public void chiudi() {
        this.inputStream.close();
    }
    
}
