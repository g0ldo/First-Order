/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filemanager;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

/**
 *
 * @author lucamazzi
 */
public class FileTestoAppend {
    
    private String nome;
    private PrintWriter outputStream;

    public FileTestoAppend(String nome) {
        this.nome = nome;

        try {
            this.outputStream = new PrintWriter(new FileOutputStream(nome, true));
        } catch (FileNotFoundException var3) {
            System.out.println("" + var3 + " " + nome);
            System.exit(0);
        }

    }

    public String getNome() {
        return this.nome;
    }

    public void scriviRiga(String riga) {
        this.outputStream.println(riga);
    }

    public void chiudi() {
        this.outputStream.close();
    }
    
    
}
