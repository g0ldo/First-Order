package Textures.Tiles;

import java.awt.image.BufferedImage;


public class Tile {
    
    public boolean collision = false;
    BufferedImage Image;
    
}
